<?php
/* Smarty version 3.1.34-dev-7, created on 2020-02-15 16:53:55
  from 'E:\zhxt\public\statistic\smarty\template\index.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e47b1a3b14dd1_73111569',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9579cc37f1007d3b83c0bf710697a675ae6603b6' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\index.html',
      1 => 1581756083,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5e47b1a3b14dd1_73111569 (Smarty_Internal_Template $_smarty_tpl) {
?>标4题<?php }
}
