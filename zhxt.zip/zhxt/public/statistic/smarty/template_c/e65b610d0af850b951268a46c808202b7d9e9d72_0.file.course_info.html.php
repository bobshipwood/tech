<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-03 19:37:20
  from 'E:\zhxt\public\statistic\smarty\template\college1\course_info.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5e4170081f64_44921069',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e65b610d0af850b951268a46c808202b7d9e9d72' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\college1\\course_info.html',
      1 => 1583235074,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5e4170081f64_44921069 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"添加页"), 0, false);
?>
	
	<div class="row" >
	 
	 <div class="col-md-3 hidden-xs"></div>
	 
	 <div class="col-md-6 col-xs-12">
		<p class="text-success visible-xs-block">左右滑动一下以便操作</p>
		
		
		<div class="table-responsive">
		  <table class="table table-striped table-bordered table-hover table-condensed">
		  
		  <thead>
			<tr>
			  <th>名称</th>
			  <th>创建人</th>
			  <th>学校</th>
			  <th>操作</th></tr>
		  </thead>
		  <tbody>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['course']->value, 'classes');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['classes']->value) {
?>
			<tr>
			  <td><?php echo $_smarty_tpl->tpl_vars['classes']->value['name'];?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['these']->value->get_name($_smarty_tpl->tpl_vars['classes']->value['create_id']);?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['these']->value->get_school($_smarty_tpl->tpl_vars['classes']->value['school_id']);?>
</td>
			  <td>
			  <a class="btn btn-sm btn-primary" href="/college/course_add/<?php echo QUERY_STRING;?>
">创建课程</a>
		
			  <a type="button"  href="/college/course_update/<?php echo QUERY_STRING;?>
&course_id=<?php echo $_smarty_tpl->tpl_vars['classes']->value['id'];?>
"  class="btn btn-sm btn-info">修改课程</a>
			  <a type="button" href="/college/course_manager/<?php echo QUERY_STRING;?>
&course_id=<?php echo $_smarty_tpl->tpl_vars['classes']->value['id'];?>
&action=del" class="btn btn-sm btn-danger">删除课程</a>
			  </td>
			</tr>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
			
		  </tbody>
		  </table>
		</div>
		
		</div>
	 
	 <div class="col-md-3 hidden-xs"></div>
	
	</div>
	
	<div class="row">
      <div class="col-md-12 col-xs-12">
		<?php echo $_smarty_tpl->tpl_vars['paging']->value;?>

	  </div>    
	</div>
	
	


<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<!-- 模态框（Modal） -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
					</button>
					<h4 class="modal-title" id="myModalLabel">
						智慧学堂温馨提示
					</h4>
				</div>
				<div class="modal-body">
					<?php echo $_smarty_tpl->tpl_vars['modal_message']->value;?>

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-primary" data-dismiss="modal">
						关闭
					</button>
					<!-- <button id="return" type="button" class="btn btn-primary"> -->
						<!-- 返回上一页 -->
					<!-- </button> -->
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<?php echo '<script'; ?>
>
		
		<?php if (isset($_smarty_tpl->tpl_vars['modal_display']->value)) {?>
			$(function () { $('#myModal').modal('<?php echo $_smarty_tpl->tpl_vars['modal_display']->value;?>
')});
		<?php } else { ?>
			$(function () { $('#myModal').modal('hide')});
		<?php }?>
		
		$(function() {
			$('#myModal').on('hide.bs.modal',
			function() {
				//alert('嘿，我听说您喜欢模态框...');
				//history.go(-1);
				//var search = window.location.search;
				//var d_url = '<?php echo $_smarty_tpl->tpl_vars['modal_url']->value;?>
';
				//var fullurl = d_url+search;
				var fullurl = '<?php echo $_smarty_tpl->tpl_vars['modal_url']->value;?>
';
				
				window.location.assign(fullurl);
			})
		});	
		//window.location.assign(url) ： 加载 URL 指定的新的 HTML 文档。 就相当于一个链接，跳转到指定的url，当前页面会转为新页面内容，可以点击后退返回上一个页面。

		//window.location.replace(url) ： 通过加载 URL 指定的文档来替换当前文档 ，这个方法是替换当前窗口页面，前后两个页面共用一个窗口，所以是没有后退返回上一页的
	<?php echo '</script'; ?>
><?php }
}
