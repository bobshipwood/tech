<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-02 20:09:22
  from 'E:\zhxt\public\statistic\smarty\template\user\user_permission.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5cf7726bc541_04273196',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '299522506c4cf5780574c6dfe9b0e6a4919ddcba' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\user\\user_permission.html',
      1 => 1583150959,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5cf7726bc541_04273196 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"列表页"), 0, false);
?>
	
	<div class="row" >
	 
	 <div class="col-md-2 hidden-xs"></div>
	 
	 <div class="col-md-8 col-xs-12">
		<p class="text-success visible-xs-block">左右滑动一下以便操作</p>
		<div class="table-responsive">
		  <table class="table table-striped table-bordered table-hover table-condensed">
		  
		  <thead>
			<tr>
			  
			  <th>名称</th>
			  <th>是否校长</th>
			  <th>是否教导主任</th>
			  <th>是否班主任</th>
			  <th>是否老师</th>
			  <th>更改权限</th>
			</tr>
		  </thead>
		  <tbody>
		
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['info']->value, 'mates');
$_smarty_tpl->tpl_vars['mates']->index = -1;
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['mates']->value) {
$_smarty_tpl->tpl_vars['mates']->index++;
$_smarty_tpl->tpl_vars['mates']->first = !$_smarty_tpl->tpl_vars['mates']->index;
$__foreach_mates_0_saved = $_smarty_tpl->tpl_vars['mates'];
?>
			<?php if ($_smarty_tpl->tpl_vars['mates']->first) {?>
				<?php continue 1;?>
			<?php }?>
			<form id = "f_<?php echo $_smarty_tpl->tpl_vars['mates']->value['id'];?>
"  method="POST">
			<tr>	  
			  <input type='hidden' name="id" value="<?php echo $_smarty_tpl->tpl_vars['mates']->value['id'];?>
">
			  <td><?php echo $_smarty_tpl->tpl_vars['mates']->value['username'];?>
</td>
			  <td>			  
				<input type="checkbox" name="is_schoolmaster" <?php if ($_smarty_tpl->tpl_vars['mates']->value['is_schoolmaster'] == 1) {?> value="1"  checked<?php } else {
}?>>
			  </td>
			  <td>			  
				<input type="checkbox" name="is_masterteacher"  <?php if ($_smarty_tpl->tpl_vars['mates']->value['is_masterteacher'] == 1) {?> value="1" checked<?php } else {
}?>>
			  </td>
			  <td>			  
				<input type="checkbox" name="is_headteacher"  <?php if ($_smarty_tpl->tpl_vars['mates']->value['is_headteacher'] == 1) {?>value="1" checked<?php } else {
}?>>
			  </td>
			  <td>			  
				<input type="checkbox" name="is_teacher"  <?php if ($_smarty_tpl->tpl_vars['mates']->value['is_teacher'] == 1) {?>value="1" checked<?php } else {
}?>>
			  </td>
			  <td>			  
				<a  id="a_<?php echo $_smarty_tpl->tpl_vars['mates']->value['id'];?>
" class="btn btn-primary">点击修改权限</a>
			  </td>
			</tr>
			</form>
			<?php
$_smarty_tpl->tpl_vars['mates'] = $__foreach_mates_0_saved;
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
		
			
		  </tbody>
		</table>
		</div>
		
		
		
		
		

	</div>
	 
	 <div class="col-md-2 hidden-xs"></div>
	
	</div>
	
	
	<div class="row">
      <div class="col-md-12 col-xs-12">
		<?php echo $_smarty_tpl->tpl_vars['paging']->value;?>

	  </div>    
	</div>
	
	

<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
echo '<script'; ?>
>	
$(function(){
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['info']->value, 'mates');
$_smarty_tpl->tpl_vars['mates']->index = -1;
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['mates']->value) {
$_smarty_tpl->tpl_vars['mates']->index++;
$_smarty_tpl->tpl_vars['mates']->first = !$_smarty_tpl->tpl_vars['mates']->index;
$__foreach_mates_1_saved = $_smarty_tpl->tpl_vars['mates'];
?>

	$("#a_<?php echo $_smarty_tpl->tpl_vars['mates']->value['id'];?>
").click(function(){
	
		$("#f_<?php echo $_smarty_tpl->tpl_vars['mates']->value['id'];?>
").submit();
		
	});
						

<?php
$_smarty_tpl->tpl_vars['mates'] = $__foreach_mates_1_saved;
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
});  	
<?php echo '</script'; ?>
>
<?php }
}
