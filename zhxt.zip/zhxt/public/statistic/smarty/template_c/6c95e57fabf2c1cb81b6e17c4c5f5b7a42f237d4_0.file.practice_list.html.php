<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-02 15:19:04
  from 'E:\zhxt\public\statistic\smarty\template\exam\practice_list.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5cb36847d178_93724695',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6c95e57fabf2c1cb81b6e17c4c5f5b7a42f237d4' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\exam\\practice_list.html',
      1 => 1582947365,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5cb36847d178_93724695 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"列表页"), 0, false);
?>
	
	<div class="row">
	 
	 <div class="col-md-2 hidden-xs"></div>
	 
	 <div class="col-md-8 col-xs-12">
		<p class="text-success visible-xs-block">左右滑动一下以便操作</p>
		<div class="table-responsive">
		  <table class="table table-striped table-bordered table-hover table-condensed">
		  
		  <thead>
			<tr>
			  <th>试卷名称</th>
			  <th>考试时间（分钟）</th>
			  <th>及格分数线</th>
			  <th>考试开始时间</th>
			  <th>考试结束时间</th>
			  <th>操作</th>
			  </tr>
		  </thead>
		  <tbody>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['infos']->value, 'info');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['info']->value) {
?>
			<tr>
			  <td><?php echo $_smarty_tpl->tpl_vars['info']->value['name'];?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['info']->value['dead_line'];?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['info']->value['pass_line'];?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['info']->value['start_time'];?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['info']->value['end_time'];?>
</td>
			  <td>
			  <a class="btn btn-sm btn-info" href="
				<?php if (empty($_GET['e_id'])) {?>
					/exam/do_practice/<?php echo QUERY_STRING;?>
&e_id=<?php echo $_smarty_tpl->tpl_vars['info']->value['id'];?>

				<?php } else { ?>
					/exam/do_practice/<?php echo $_smarty_tpl->tpl_vars['these']->value->replace_query('e_id',$_smarty_tpl->tpl_vars['info']->value['id']);?>

				<?php }?>
			  " role="button">练习所有题目</a>
			  </td>
			</tr>
			<?php
}
} else {
?>
			暂无数据
			<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
			
		  </tbody>
		</table>
		</div>
		</div>
	 
	 <div class="col-md-2 hidden-xs"></div>
	
	</div>
	
	<div class="row">
      <div class="col-md-12 col-xs-12">
		<?php echo $_smarty_tpl->tpl_vars['paging']->value;?>

	  </div>    
	</div>
	
	


<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
