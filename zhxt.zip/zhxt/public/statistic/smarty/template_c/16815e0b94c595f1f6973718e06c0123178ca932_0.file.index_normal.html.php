<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-04 16:37:45
  from 'E:\zhxt\public\statistic\smarty\template\user\index_normal.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5f68d9be0b70_80463079',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '16815e0b94c595f1f6973718e06c0123178ca932' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\user\\index_normal.html',
      1 => 1583311055,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5f68d9be0b70_80463079 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"首页"), 0, false);
?>


<div id="myCarousel" class="carousel slide">
    <!-- 轮播（Carousel）指标 -->
    <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>   
    <!-- 轮播（Carousel）项目 -->
    <div class="carousel-inner">
        <div class="item active">
            <img src="/public/statistic/images/2.png" alt="First slide">
            <div class="carousel-caption">安全复工生产</div>
        </div>
        <div class="item">
            <img src="/public/statistic/images/1.png" alt="Second slide">
            <div class="carousel-caption">职业健康知识培训</div>
        </div>
        <div class="item">
            <img src="/public/statistic/images/1.png" alt="Third slide">
            <div class="carousel-caption">职业健康知识培训</div>
        </div>
    </div>
    <!-- 轮播（Carousel）导航 -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<div class="row" style="margin-top:10px">

<p class="clearfix" style="padding-left:15px;padding-right:15px"><span style="float:left;font-size:20px;">2020复工生产必备</span> <span style="float:right">查看更多</span></p>

    <div class="col-sm-6 col-md-3">
         <div class="thumbnail">
            <img src="/public/statistic/images/3.png" 
             alt="通用的占位符缩略图">
            <div class="caption">
                <h3>课程标题</h3>
                <p>主讲人：严冬</p>
				<p>点击量：2334</p>
                <p>
                    <a href="#" class="btn btn-primary" role="button">
                        开始学习
                    </a> 
                    <a href="#" class="btn btn-default" role="button">
                        按钮
                    </a>
                </p>
            </div>
         </div>
    </div>
    <div class="col-sm-6 col-md-3">
        <div class="thumbnail">
            <img src="/public/statistic/images/3.png" 
            alt="通用的占位符缩略图">
            <div class="caption">
                <h3>课程标题</h3>
                <p>主讲人：严冬</p>
				<p>点击量：2334</p>
                <p>
                    <a href="#" class="btn btn-primary" role="button">
                        开始学习
                    </a> 
                    <a href="#" class="btn btn-default" role="button">
                        按钮
                    </a>
                </p>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-3">
        <div class="thumbnail">
            <img src="/public/statistic/images/3.png" 
            alt="通用的占位符缩略图">
            <div class="caption">
                <h3>课程标题</h3>
                <p>主讲人：严冬</p>
				<p>点击量：2334</p>
                <p>
                    <a href="#" class="btn btn-primary" role="button">
                        开始学习
                    </a> 
                    <a href="#" class="btn btn-default" role="button">
                        按钮
                    </a>
                </p>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-3">
        <div class="thumbnail">
            <img src="/public/statistic/images/3.png" 
            alt="通用的占位符缩略图">
            <div class="caption">
                <h3>课程标题</h3>
                <p>主讲人：严冬</p>
				<p>点击量：2334</p>
                <p>
                    <a href="#" class="btn btn-primary" role="button">
                        开始学习
                    </a> 
                    <a href="#" class="btn btn-default" role="button">
                        按钮
                    </a>
                </p>
            </div>
        </div>
    </div>
</div>




<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
