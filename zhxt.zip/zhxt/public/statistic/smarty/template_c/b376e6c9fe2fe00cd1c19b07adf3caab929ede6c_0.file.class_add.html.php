<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-02 15:18:32
  from 'E:\zhxt\public\statistic\smarty\template\college\class_add.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5cb348339845_12302369',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b376e6c9fe2fe00cd1c19b07adf3caab929ede6c' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\college\\class_add.html',
      1 => 1582509491,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5cb348339845_12302369 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"添加页"), 0, false);
?>
	
	<div class="row" style="margin-top:30px;">
	 
	 <div class="col-md-3 hidden-xs"></div>
	 
	 <div class="col-md-6 col-xs-12">
		<form role="form" method="post"  >
			<div class="form-group">
				<label for="school">选择学校</label>
				<select class="form-control" name='school'>
				  
				  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['school']->value, 'schools');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['schools']->value) {
?>
					<option value='<?php echo $_smarty_tpl->tpl_vars['schools']->value['id'];?>
'><?php echo $_smarty_tpl->tpl_vars['schools']->value['name'];?>
</option>
				  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				  
				</select>
				<p class="help-block"></p>
			</div>
			
			<div class="form-group">
				<label for="teacher">任课老师</label>
				<input type="text" class="form-control" id="teacher" name = "teacher"
					   placeholder="请输入老师名称">
				<p class="help-block"></p>
			</div>
				
			<div class="form-group">
				<label for="classname">班级名称</label>
				<input type="text" class="form-control" id="classname" name = "classname"
					   placeholder="请输入班级名称">
				<p class="help-block"></p>
			</div>
			
			<div class="form-group">
				<label>是否共享</label>	
					<label class="radio-inline" style="margin:10px;">
						<input type="radio" name="optionsRadios" id="optionsRadios1" value="1" checked>否
					</label>
			
					<label class="radio-inline">
						<input type="radio" name="optionsRadios" id="optionsRadios2" value="0">是
					</label>		
				<p class="help-block">选择是，校外的老师也能看到该课程</p>
			</div>
			
			<!-- <div class="form-group"> -->
				<!-- <label>默认的复选框和单选按钮的实例</label> -->
					<!-- <div class="checkbox"> -->
						<!-- <label><input type="checkbox" value="">选项 1</label> -->
					<!-- </div> -->
					<!-- <div class="checkbox"> -->
						<!-- <label><input type="checkbox" value="">选项 2</label> -->
					<!-- </div> -->
					<!-- <div class="radio"> -->
						<!-- <label> -->
							<!-- <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked> 选项 1 -->
						<!-- </label> -->
					<!-- </div> -->
					<!-- <div class="radio"> -->
						<!-- <label> -->
							<!-- <input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">选项 2 - 选择它将会取消选择选项 1 -->
						<!-- </label> -->
					<!-- </div> -->
			<!-- </div> -->
			
			<button type="submit" class="btn btn-default">提交</button>
		</form>
        
	 </div>
	 
	 <div class="col-md-3 hidden-xs"></div>
	
	</div>
	
	


<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
