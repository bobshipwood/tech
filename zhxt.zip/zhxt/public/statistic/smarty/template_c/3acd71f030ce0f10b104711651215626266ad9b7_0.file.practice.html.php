<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-01 22:34:50
  from 'E:\zhxt\public\statistic\smarty\template\exam\practice.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5bc80ad70913_20019390',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3acd71f030ce0f10b104711651215626266ad9b7' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\exam\\practice.html',
      1 => 1583073272,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5bc80ad70913_20019390 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"练习页"), 0, false);
?>


	
<div class="row">
	<div class="col-md-2 hidden-xs"></div>
	<div class="col-md-8 col-xs-12 ">
		<div class="col-md-3 col-xs-2" style="padding:0"><a type="button" href="<?php echo $_smarty_tpl->tpl_vars['head_link']->value;?>
" class="btn btn-info pull-left"><span class="glyphicon glyphicon-circle-arrow-left"></span></a></div>
		
		<div class="col-md-6 col-xs-8 " style="padding:0;">
			<a type="button" class="btn btn-info" style="width:100%">
				<?php if ($_smarty_tpl->tpl_vars['question_actual']->value[$_GET['q_page']-1]['type'] == 1) {?>
					单项选择题 (每题<?php echo $_smarty_tpl->tpl_vars['question_actual']->value[$_GET['q_page']-1]['pts'];?>
分)
				<?php } else { ?>
					多项选择题 (每题<?php echo $_smarty_tpl->tpl_vars['question_actual']->value[$_GET['q_page']-1]['pts'];?>
分)
				<?php }?>
			</a>
		</div>
		<div class="col-md-3 col-xs-2" style="padding:0"><a type="button" href="<?php echo $_smarty_tpl->tpl_vars['footer_link']->value;?>
" class="btn btn-info pull-right"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></div>
	</div>   
	<div class="col-md-2 hidden-xs"></div>	  
</div>

<div class="row" style="margin-top:15px">
<div class="col-md-2 hidden-xs"></div>
	<div class="col-md-8 col-xs-12">
	<p class="lead text-info"><?php echo $_smarty_tpl->tpl_vars['question_actual']->value[$_GET['q_page']-1]['name'];?>
</p>
	</div>  
<div class="col-md-2 hidden-xs"></div>	
</div>

<div class="row" style="margin-top:15px">
<div class="col-md-2 hidden-xs"></div>
	<div class="col-md-8 col-xs-12" >
	 
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['question_actual']->value[$_GET['q_page']-1]['answer_list'], 'questions', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['questions']->value) {
?>
		<div>
			<span class="lead text-info"><?php echo $_smarty_tpl->tpl_vars['array']->value[$_smarty_tpl->tpl_vars['key']->value];?>
, <span>
			<span class="lead text-info"><?php echo $_smarty_tpl->tpl_vars['questions']->value;?>
<span>
		</div>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	</div>  
<div class="col-md-2 hidden-xs"></div>	
</div>

<div class="row" style="margin-top:15px">
<div class="col-md-2 hidden-xs"></div>
	<div class="col-md-8 col-xs-12" >
	
	<?php if ($_smarty_tpl->tpl_vars['question_actual']->value[$_GET['q_page']-1]['type'] == 1) {?>
		<?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['i']->step = 1;$_smarty_tpl->tpl_vars['i']->total = (int) ceil(($_smarty_tpl->tpl_vars['i']->step > 0 ? $_smarty_tpl->tpl_vars['key']->value+1 - (0) : 0-($_smarty_tpl->tpl_vars['key']->value)+1)/abs($_smarty_tpl->tpl_vars['i']->step));
if ($_smarty_tpl->tpl_vars['i']->total > 0) {
for ($_smarty_tpl->tpl_vars['i']->value = 0, $_smarty_tpl->tpl_vars['i']->iteration = 1;$_smarty_tpl->tpl_vars['i']->iteration <= $_smarty_tpl->tpl_vars['i']->total;$_smarty_tpl->tpl_vars['i']->value += $_smarty_tpl->tpl_vars['i']->step, $_smarty_tpl->tpl_vars['i']->iteration++) {
$_smarty_tpl->tpl_vars['i']->first = $_smarty_tpl->tpl_vars['i']->iteration === 1;$_smarty_tpl->tpl_vars['i']->last = $_smarty_tpl->tpl_vars['i']->iteration === $_smarty_tpl->tpl_vars['i']->total;?>
			<label class="radio-inline">
				<input type="radio" name="radionames" id="radioid_<?php echo $_smarty_tpl->tpl_vars['i']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['array']->value[$_smarty_tpl->tpl_vars['i']->value];?>
"> <?php echo $_smarty_tpl->tpl_vars['array']->value[$_smarty_tpl->tpl_vars['i']->value];?>

			</label>
		<?php }
}
?>	
	<?php } else { ?>
		<?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['i']->step = 1;$_smarty_tpl->tpl_vars['i']->total = (int) ceil(($_smarty_tpl->tpl_vars['i']->step > 0 ? $_smarty_tpl->tpl_vars['key']->value+1 - (0) : 0-($_smarty_tpl->tpl_vars['key']->value)+1)/abs($_smarty_tpl->tpl_vars['i']->step));
if ($_smarty_tpl->tpl_vars['i']->total > 0) {
for ($_smarty_tpl->tpl_vars['i']->value = 0, $_smarty_tpl->tpl_vars['i']->iteration = 1;$_smarty_tpl->tpl_vars['i']->iteration <= $_smarty_tpl->tpl_vars['i']->total;$_smarty_tpl->tpl_vars['i']->value += $_smarty_tpl->tpl_vars['i']->step, $_smarty_tpl->tpl_vars['i']->iteration++) {
$_smarty_tpl->tpl_vars['i']->first = $_smarty_tpl->tpl_vars['i']->iteration === 1;$_smarty_tpl->tpl_vars['i']->last = $_smarty_tpl->tpl_vars['i']->iteration === $_smarty_tpl->tpl_vars['i']->total;?>
			<label class="checkbox-inline">
				<input type="checkbox" name="checkbox_<?php echo $_smarty_tpl->tpl_vars['i']->value;?>
" id="checkbox_<?php echo $_smarty_tpl->tpl_vars['i']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['array']->value[$_smarty_tpl->tpl_vars['i']->value];?>
"> <?php echo $_smarty_tpl->tpl_vars['array']->value[$_smarty_tpl->tpl_vars['i']->value];?>

			</label>
		<?php }
}
?>
	<?php }?>
	
	</div>  
<div class="col-md-2 hidden-xs"></div>	
</div>

<div class="row" style="margin-top:15px">
<div class="col-md-2 hidden-xs"></div>
	<div class="col-md-8 col-xs-12" >
	<button id = "button" type="button" class="btn btn-info">提交答案</button>
	<div id="myAlert" class="alert" style="display:none">
				<a id="closed" href="#">&times;</a>
				<strong id="alert_text"></strong>
	</div>
	</div>  
<div class="col-md-2 hidden-xs"></div>	
</div>

<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
echo '<script'; ?>
>
$(function(){

	$("#button").click(function(e){
	
		$("#myAlert").hide();
		
		$("#myAlert").removeClass("alert-success");
		
		$("#myAlert").removeClass("alert-warning");
			
		<?php if ($_smarty_tpl->tpl_vars['question_actual']->value[$_GET['q_page']-1]['type'] == 1) {?>
			var correct = <?php echo $_smarty_tpl->tpl_vars['question_actual']->value[$_GET['q_page']-1]['correct_answer'];?>
;
			
			var user_input = '';
			
			$("input[type='radio']").each(function(){
				if($(this).prop("checked")!=false){
					user_input = $(this).val();
				}	
			});
			
			if(user_input === correct){		
				$("#myAlert").addClass("alert-success");
				$("#alert_text").text('恭喜你，答题正确');
				$("#myAlert").show();
			}else{
				$("#myAlert").addClass("alert-warning");
				$("#alert_text").text('答题错误，请加油');
				$("#myAlert").show();
			}		
		<?php } else { ?>
		
			var correct = <?php echo $_smarty_tpl->tpl_vars['question_actual']->value[$_GET['q_page']-1]['correct_answer'];?>
;
			
			var user_input = new Array();
			
			$("input[type='checkbox']").each(function(){
				if($(this).prop("checked")!=false){
					user_input.push($(this).val());
				}	
			});
			
			if(user_input.toString() === correct.toString()){		
				$("#myAlert").addClass("alert-success");
				$("#alert_text").text('恭喜你，答题正确');
				$("#myAlert").show();
			}else{
				$("#myAlert").addClass("alert-warning");
				$("#alert_text").text('答题错误，请加油');
				$("#myAlert").show();
			}		
			
		<?php }?>
			
		
	});
	 
});
	


<?php echo '</script'; ?>
><?php }
}
