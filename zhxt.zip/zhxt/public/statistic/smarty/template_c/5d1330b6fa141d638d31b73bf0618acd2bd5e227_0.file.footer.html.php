<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-01 22:33:34
  from 'E:\zhxt\public\statistic\smarty\template\footer.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5bc7becb79b6_47687932',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5d1330b6fa141d638d31b73bf0618acd2bd5e227' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\footer.html',
      1 => 1582272782,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e5bc7becb79b6_47687932 (Smarty_Internal_Template $_smarty_tpl) {
?>	<div class="row" style="margin-top:20px;">
		<div class="col-md-4 hidden-xs"></div>
		<div class="col-md-4 col-xs-12">	  
			<address>
			  <strong>安云通培训平台.</strong><br>
			  广东省广州黄埔区<br>
			  <abbr title="Phone">P:</abbr> (123) 456-7890
			</address>

			<address>
			  <strong>联系我们</strong><br>
			  <a href="mailto:#">first.last@example.com</a>
			</address>
			<a target="_blank" href="http://www.miibeian.gov.cn/" style="font-size: 15px;">粤ICP备17110465号-1</a>
		</div>
		<div class="col-md-4 hidden-xs"></div>
	</div>
   
</div><!-- container的结束符号 -->

	<!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"><?php echo '</script'; ?>
>
    <!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"><?php echo '</script'; ?>
>
	
	</body>
</html>



<?php }
}
