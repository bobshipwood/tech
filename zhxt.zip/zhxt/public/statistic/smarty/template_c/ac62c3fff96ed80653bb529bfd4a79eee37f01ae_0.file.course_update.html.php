<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-03 19:11:56
  from 'E:\zhxt\public\statistic\smarty\template\college1\course_update.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5e3b7cab2d43_05380137',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ac62c3fff96ed80653bb529bfd4a79eee37f01ae' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\college1\\course_update.html',
      1 => 1583233914,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5e3b7cab2d43_05380137 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"添加页"), 0, false);
?>
	
	<div class="row" style="margin-top:30px;">
	 
	 <div class="col-md-3 hidden-xs"></div>
	 
	 <div class="col-md-6 col-xs-12">
		<form role="form" method="post"  >
			
			<div class="form-group">
				<label for="name">课程名称</label>
				<input type="text" class="form-control" id="name" name = "name"
					  value="<?php echo $_smarty_tpl->tpl_vars['info']->value['name'];?>
" placeholder="请输入课程名称">
				<p class="help-block"></p>
			</div>
				
			<div class="form-group">
				<label for="url">链接地址</label>
				<input type="text" class="form-control" id="url" name = "url"
				value="<?php echo $_smarty_tpl->tpl_vars['info']->value['url'];?>
" placeholder="例子：http://www.baidu.com">
				<p class="help-block"></p>
			</div>
			
			<button type="submit" class="btn btn-default">提交</button>
		</form>
        
	 </div>
	 
	 <div class="col-md-3 hidden-xs"></div>
	
	</div>
	
<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
	<!-- 模态框（Modal） -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
					</button>
					<h4 class="modal-title" id="myModalLabel">
						智慧学堂温馨提示
					</h4>
				</div>
				<div class="modal-body">
					<?php echo $_smarty_tpl->tpl_vars['modal_message']->value;?>

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-primary" data-dismiss="modal">
						关闭
					</button>
					<!-- <button id="return" type="button" class="btn btn-primary"> -->
						<!-- 返回上一页 -->
					<!-- </button> -->
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<?php echo '<script'; ?>
>
		
		<?php if (isset($_smarty_tpl->tpl_vars['modal_display']->value)) {?>
			$(function () { $('#myModal').modal('<?php echo $_smarty_tpl->tpl_vars['modal_display']->value;?>
')});
		<?php } else { ?>
			$(function () { $('#myModal').modal('hide')});
		<?php }?>
		
		$(function() {
			$('#myModal').on('hide.bs.modal',
			function() {
				//alert('嘿，我听说您喜欢模态框...');
				//history.go(-1);
				//var search = window.location.search;
				//var d_url = '<?php echo $_smarty_tpl->tpl_vars['modal_url']->value;?>
';
				//var fullurl = d_url+search;
				var fullurl = '<?php echo $_smarty_tpl->tpl_vars['modal_url']->value;?>
';
				
				window.location.assign(fullurl);
			})
		});	
		//window.location.assign(url) ： 加载 URL 指定的新的 HTML 文档。 就相当于一个链接，跳转到指定的url，当前页面会转为新页面内容，可以点击后退返回上一个页面。

		//window.location.replace(url) ： 通过加载 URL 指定的文档来替换当前文档 ，这个方法是替换当前窗口页面，前后两个页面共用一个窗口，所以是没有后退返回上一页的
	<?php echo '</script'; ?>
><?php }
}
