<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-02 15:19:00
  from 'E:\zhxt\public\statistic\smarty\template\exam\study.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5cb364518748_89840639',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8f35f583b49560c0794a4ad30c50a13300a82cb4' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\exam\\study.html',
      1 => 1582551212,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5cb364518748_89840639 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"练习页"), 0, false);
?>
	
	<div class="row" >
	 
	 <div class="col-md-2 hidden-xs"></div>
	 
	 <div class="col-md-8 col-xs-12">
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['class']->value, 'classes');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['classes']->value) {
?>
		<div class="panel panel-primary">	
			<div class="panel-heading" data-toggle="collapse" data-target="#c_<?php echo $_smarty_tpl->tpl_vars['classes']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['classes']->value['classname'];?>
 >>>>> 点击展开课程</div>
			<div class="panel-body collapse" id="c_<?php echo $_smarty_tpl->tpl_vars['classes']->value['id'];?>
">
				<div class="list-group">
				
				<?php $_smarty_tpl->_assignInScope('course', $_smarty_tpl->tpl_vars['these']->value->select("select * from yd_course where class_id = ".((string)$_smarty_tpl->tpl_vars['classes']->value['id'])));?>
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['course']->value, 'courses');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['courses']->value) {
?>
				  <!-- <a href="#" class="list-group-item list-group-item-primary disabled"> -->
					<!-- 已过上课时间 -->
				  <!-- </a> -->
					<a href="<?php echo $_smarty_tpl->tpl_vars['courses']->value['url'];?>
" class="list-group-item list-group-item-info"><?php echo $_smarty_tpl->tpl_vars['courses']->value['name'];?>
</a>
				<?php
}
} else {
?>
					<a href="#" class="list-group-item list-group-item-info">快叫你的老师添加课程吧！</a>
				<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				</div>
			</div>
			<!-- <div class="panel-footer">培训班已结束</div> -->	
		</div>
		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
		
	 </div>
	 <div class="col-md-2 hidden-xs"></div>
	
	</div>
	
	<div class="row">
      <div class="col-md-12 col-xs-12">
		<?php echo $_smarty_tpl->tpl_vars['paging']->value;?>

	  </div>    
	</div>
	
<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
