<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-02 17:10:45
  from 'E:\zhxt\public\statistic\smarty\template\college\classmate_special.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5ccd95eb7802_27789812',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a71d391b883043406d43d0c3c4fd00b1574b8d3d' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\college\\classmate_special.html',
      1 => 1582530424,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5ccd95eb7802_27789812 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"添加页"), 0, false);
?>
	
	<div class="row" >
	 
	 <div class="col-md-3 hidden-xs"></div>
	 
	 <div class="col-md-6 col-xs-12">
		<p class="text-success visible-xs-block">左右滑动一下以便操作</p>
		<div class="table-responsive">
		  <table class="table table-striped table-bordered table-hover table-condensed">
		  
		  <thead>
			<tr>
			  <th>id</th>
			  <th>名称</th>
			  <th><button id="button1" type="button" class="btn btn-primary" >点击全选该页所有人</button></th>
			</tr>
		  </thead>
		  <tbody>
		<form method="POST">
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['schoolmate']->value, 'mates');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['mates']->value) {
?>
			<tr>
			  <td><?php echo $_smarty_tpl->tpl_vars['mates']->value['id'];?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['mates']->value['username'];?>
</td>
			  <td><input type="checkbox" name="optionsRadios[]" value="<?php echo $_smarty_tpl->tpl_vars['mates']->value['id'];?>
" ></td>
			</tr>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
		
			
		  </tbody>
		</table>
		</div>
		
		
		<button type="submit" class="btn btn-primary">提交名单</button>
		
		</form>

	</div>
	 
	 <div class="col-md-3 hidden-xs"></div>
	
	</div>
	
	
	<div class="row">
      <div class="col-md-12 col-xs-12">
		<?php echo $_smarty_tpl->tpl_vars['paging']->value;?>

	  </div>    
	</div>
	
	

<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
echo '<script'; ?>
>	
$(function() {
        $("#button1").click(function(){
		
			$("input:checkbox[name='optionsRadios[]']").prop("checked", true);

			//往button里 添加data-loading-text="Loading..."
            //$(this).button('loading').delay(1000).queue(function() {
            // $(this).button('reset');
            // $(this).dequeue(); 
            //});
        });
		
});  	
<?php echo '</script'; ?>
><?php }
}
