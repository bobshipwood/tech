<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-03 16:09:14
  from 'E:\zhxt\public\statistic\smarty\template\user\login.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5e10aa042d63_03639332',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a39b86414cfac3d6150aa5e8dca1c8d2a4c5ed5b' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\user\\login.html',
      1 => 1583222951,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e5e10aa042d63_03639332 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="zh-CN">
	<head>
    <meta charset="utf-8">
	<!-- Bootstrap 不支持 IE 古老的兼容模式。为了让 IE 浏览器运行最新的渲染模式下 -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
	<!-- 将下面的 <meta> 标签加入到页面中，可以让部分国产浏览器默认采用高速模式渲染页面： -->
	<meta name="renderer" content="webkit">
	<title>登陆页</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- HTML5 shim 和 Respond.js 是为了让 IE8 支持 HTML5 元素和媒体查询（media queries）功能 -->
    <!-- 警告：通过 file:// 协议（就是直接将 html 页面拖拽到浏览器中）访问页面时 Respond.js 不起作用 -->
    <!--[if lt IE 9]>
      <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"><?php echo '</script'; ?>
>
      <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"><?php echo '</script'; ?>
>
    <![endif]-->
	</head>
	<body>
	<style>
	body{
		background-image:url(https://m.gdhse.com/web/resource/images/bg-login.png);
	}
	</style>
	<div class="container" >
	
		<div class="row" style="margin-top:50px">
		<div class = "col-md-3 hidden-xs"></div>
		<div class = "col-md-6 col-xs-12">
			<img class="img-responsive center-block" src="https://m.gdhse.com/attachment/images/global/WmXS10NMcfiXys3Xp7Y7o1d731d2xd.jpg">
		</div>
		<div class = "col-md-3 hidden-xs"></div>
		</div>
		
		<div class="row" style="margin-top:100px">
			<div class = "col-md-3 hidden-xs"></div>
			<div class = "col-md-6 col-xs-12">
				<form class="form-horizontal" role="form" method="post" >
				  <div class="form-group">
					<label for="username" class="col-sm-2 control-label">用户名</label>
					<div class="col-sm-10">
					  <input type="text" class="form-control" id="username" name='username' placeholder="请输入用户名">
					</div>
				  </div>
				  <div class="form-group">
					<label for="password" class="col-sm-2 control-label">密码</label>
					<div class="col-sm-10">
					  <input type="text" class="form-control" id="password" name='password' placeholder="请输入密码">
					</div>
				  </div>
				  <!-- <div class="form-group"> -->
					<!-- <div class="col-sm-offset-2 col-sm-10"> -->
					  <!-- <div class="checkbox"> -->
						<!-- <label> -->
						  <!-- <input type="checkbox">请记住我 -->
						<!-- </label> -->
					  <!-- </div> -->
					<!-- </div> -->
				  <!-- </div> -->
				  <div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
					  <button type="submit" class="btn btn-default">登录</button>
					</div>
				  </div>
				</form>
			</div>
			<div class = "col-md-3 hidden-xs"></div>
		</div>
	
	</div>
</div>

	<!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"><?php echo '</script'; ?>
>
    <!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"><?php echo '</script'; ?>
>
		<!-- 模态框（Modal） -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
					</button>
					<h4 class="modal-title" id="myModalLabel">
						智慧学堂温馨提示
					</h4>
				</div>
				<div class="modal-body">
					<?php echo $_smarty_tpl->tpl_vars['modal_message']->value;?>

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-primary" data-dismiss="modal">
						关闭
					</button>
					<!-- <button id="return" type="button" class="btn btn-primary"> -->
						<!-- 返回上一页 -->
					<!-- </button> -->
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<?php echo '<script'; ?>
>
		
		<?php if (isset($_smarty_tpl->tpl_vars['modal_display']->value)) {?>
			$(function () { $('#myModal').modal('<?php echo $_smarty_tpl->tpl_vars['modal_display']->value;?>
')});
		<?php } else { ?>
			$(function () { $('#myModal').modal('hide')});
		<?php }?>
		
		$(function() {
			$('#myModal').on('hide.bs.modal',
			function() {
				//alert('嘿，我听说您喜欢模态框...');
				//history.go(-1);
				//var search = window.location.search;
				//var d_url = '<?php echo $_smarty_tpl->tpl_vars['modal_url']->value;?>
';
				//var fullurl = d_url+search;
				var fullurl = '<?php echo $_smarty_tpl->tpl_vars['modal_url']->value;?>
';
				window.location.assign(fullurl);
			})
		});	
		//window.location.assign(url) ： 加载 URL 指定的新的 HTML 文档。 就相当于一个链接，跳转到指定的url，当前页面会转为新页面内容，可以点击后退返回上一个页面。

		//window.location.replace(url) ： 通过加载 URL 指定的文档来替换当前文档 ，这个方法是替换当前窗口页面，前后两个页面共用一个窗口，所以是没有后退返回上一页的
	<?php echo '</script'; ?>
>
	</body>
</html>


<?php }
}
