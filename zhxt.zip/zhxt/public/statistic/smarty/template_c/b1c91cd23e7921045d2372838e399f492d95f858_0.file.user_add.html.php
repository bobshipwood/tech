<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-02 13:38:11
  from 'E:\zhxt\public\statistic\smarty\template\user\user_add.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5c9bc3ad55b4_31494876',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b1c91cd23e7921045d2372838e399f492d95f858' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\user\\user_add.html',
      1 => 1582188858,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5c9bc3ad55b4_31494876 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"添加页"), 0, false);
?>


	
	<div class="row" style="margin-top:30px;">
	 
	 <div class="col-md-3 hidden-xs"></div>
	 
	 <div class="col-md-6 col-xs-12">
		<form role="form" method="post"  >
			<div class="form-group">
				<label for="username">用户名</label>
				<input type="text" class="form-control" id="username" name = "username"
					   placeholder="请输入用户名">
				<p class="help-block"></p>
			</div>
			<div class="form-group">
				<label for="password">密码</label>
				<input type="password" class="form-control" id="password" name = "password"
					   placeholder="请输入密码">
				<p class="help-block"></p>
			</div>
			<div class="form-group">
				<label for="role">选择角色</label>
				<select class="form-control" name='role'>
				  
				  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['role']->value, 'roles');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['roles']->value) {
?>
					<option value='<?php echo $_smarty_tpl->tpl_vars['roles']->value['id'];?>
'><?php echo $_smarty_tpl->tpl_vars['roles']->value['name'];?>
</option>
				  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				  
				</select>
				<p class="help-block"></p>
			</div>
			
			<div class="form-group">
				<label for="school_id">选择学校</label>
				<select class="form-control" name='school_id'>
				  
				  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['school']->value, 'schools');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['schools']->value) {
?>
					<option value='<?php echo $_smarty_tpl->tpl_vars['schools']->value['id'];?>
'><?php echo $_smarty_tpl->tpl_vars['schools']->value['name'];?>
</option>
				  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				  
				</select>
				<p class="help-block"></p>
			</div>
			
			<button type="submit" class="btn btn-default">提交</button>
		</form>
        
	 </div>
	 
	 <div class="col-md-3 hidden-xs"></div>
	
	</div>
	
	


<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
