<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-02 15:18:34
  from 'E:\zhxt\public\statistic\smarty\template\college\class_mate.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5cb34a359373_08793326',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8aa85ae62a3f0dd711a0a6be6f98512cdd04bf7e' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\college\\class_mate.html',
      1 => 1582550931,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5cb34a359373_08793326 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"添加页"), 0, false);
?>
	
	<div class="row">
	 
	 <div class="col-md-2 hidden-xs"></div>
	 
	 <div class="col-md-8 col-xs-12">
		<p class="text-success visible-xs-block">左右滑动一下以便操作</p>
		<div class="table-responsive">
		  <table class="table table-striped table-bordered table-hover table-condensed">
		  
		  <thead>
			<tr>
			  <th>名称</th>
			  <th>申请人</th>
			  <th>任课老师</th>
			  <th>学校</th>
			  <th>操作</th></tr>
		  </thead>
		  <tbody>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['class']->value, 'classes');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['classes']->value) {
?>
			<tr>
			  <td><?php echo $_smarty_tpl->tpl_vars['classes']->value['classname'];?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['these']->value->get_name($_smarty_tpl->tpl_vars['classes']->value['creater_id']);?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['classes']->value['teacher'];?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['these']->value->get_school($_smarty_tpl->tpl_vars['classes']->value['school_id']);?>
</td>
			  <td>
			  <a class="btn btn-sm btn-info" href="
				<?php if (empty($_GET['c_id'])) {?>
					/college/classmate_all/<?php echo QUERY_STRING;?>
&c_id=<?php echo $_smarty_tpl->tpl_vars['classes']->value['id'];?>

				<?php } else { ?>
					/college/classmate_all/<?php echo $_smarty_tpl->tpl_vars['these']->value->replace_query('c_id',$_smarty_tpl->tpl_vars['classes']->value['id']);?>

				<?php }?>
			  " role="button">纳入本校全部学员</a>
			  
			  <a class="btn btn-sm btn-info" href="
				<?php if (empty($_GET['c_id'])) {?>
					/college/classmate_special/<?php echo QUERY_STRING;?>
&c_id=<?php echo $_smarty_tpl->tpl_vars['classes']->value['id'];?>

				<?php } else { ?>
					/college/classmate_special/<?php echo $_smarty_tpl->tpl_vars['these']->value->replace_query('c_id',$_smarty_tpl->tpl_vars['classes']->value['id']);?>

				<?php }?>
			  " role="button">纳入指定学员</a>
			  </td>
			</tr>
			<?php
}
} else {
?>
			暂无数据
			<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
			
		  </tbody>
		</table>
		</div>
		</div>
	 
	 <div class="col-md-2 hidden-xs"></div>
	
	</div>
	
	<div class="row">
      <div class="col-md-12 col-xs-12">
		<?php echo $_smarty_tpl->tpl_vars['paging']->value;?>

	  </div>    
	</div>
	
	


<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
