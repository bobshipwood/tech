<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-02 20:29:11
  from 'E:\zhxt\public\statistic\smarty\template\user\index.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5cfc17dfbee6_22450798',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bbc4cabf89e4ad42004f8145cde7e956a77a3876' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\user\\index.html',
      1 => 1582821363,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5cfc17dfbee6_22450798 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"首页"), 0, false);
?>


	
	<div class="row">
      
	  <div class="col-md-12 col-xs-12">
			<div class="jumbotron">
				<div class="container">
					<h1>欢迎使用！</h1>
					<p>这是一个可以获得知识的平台.</p>
					<p><a class="btn btn-primary btn-lg" role="button">
					 学习更多</a>
					</p>
				</div>
			</div>
	  </div>      
	</div>
	
	


<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
