<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-03 17:19:48
  from 'E:\zhxt\public\statistic\smarty\template\header.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5e2134a0b8e0_52356557',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fd8ee417f3921ebe45b10e39b2639dcc2d6b201c' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\header.html',
      1 => 1583227137,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e5e2134a0b8e0_52356557 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="zh-CN">
	<head>
    <meta charset="utf-8">
	<!-- Bootstrap 不支持 IE 古老的兼容模式。为了让 IE 浏览器运行最新的渲染模式下 -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
	<!-- 将下面的 <meta> 标签加入到页面中，可以让部分国产浏览器默认采用高速模式渲染页面： -->
	<meta name="renderer" content="webkit">
	<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- HTML5 shim 和 Respond.js 是为了让 IE8 支持 HTML5 元素和媒体查询（media queries）功能 -->
    <!-- 警告：通过 file:// 协议（就是直接将 html 页面拖拽到浏览器中）访问页面时 Respond.js 不起作用 -->
    <!--[if lt IE 9]>
      <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"><?php echo '</script'; ?>
>
      <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"><?php echo '</script'; ?>
>
    <![endif]-->
	</head>
	<body>
	
	<div class="container">
	
	<div class="row">
	 <div class="col-md-12 col-xs-12">
        <nav class="navbar navbar-default" role="navigation">
			<div class="container-fluid"> 
				<div class="navbar-header ">
					<button type="button" class="navbar-toggle" data-toggle="collapse"
							data-target="#example-navbar-collapse">
						<span class="sr-only">切换导航</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="#">培训学堂</a>
				</div>
				
				<!-- <form class="navbar-form navbar-left hidden-xs hidden-md" role="search"> -->
					<!-- <div class="form-group"> -->
						<!-- <input type="text" class="form-control" placeholder="Search"> -->
					<!-- </div> -->
					<!-- <button type="submit" class="btn btn-default">提交</button> -->
				<!-- </form> -->
				
				<!-- <ul class="nav navbar-nav navbar-right hidden-xs">  -->
					<!-- <li><a href="#"><span class="glyphicon glyphicon-user"></span> 注册</a></li> -->
					<!-- <li><a href="/user/logout/<?php echo QUERY_STRING;?>
"><span class="glyphicon glyphicon-log-in"></span> 退出登陆</a></li>  -->
				<!-- </ul>  -->
				
				<div class="collapse navbar-collapse navbar-right" id="example-navbar-collapse" >
					<ul class="nav navbar-nav">
						<!-- <li class="active"> -->
						<?php if ($_smarty_tpl->tpl_vars['user_info']->value[0]['is_admin']) {?>
						<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">超级用户管理<b class="caret"></b></a>
						<ul class="dropdown-menu">						
							<li><a href="/user/user_add/<?php echo QUERY_STRING;?>
">添加用户(未)</a></li>
							<li class="divider"></li>
							<li><a href="/user/user_permission/<?php echo QUERY_STRING;?>
">角色菜单设置</a></li>
							
						</ul>
						</li>
						<?php }?>
						
						<?php if ($_smarty_tpl->tpl_vars['user_info']->value[0]['is_admin'] || $_smarty_tpl->tpl_vars['user_info']->value[0]['is_schoolmaster']) {?>
						<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">校长权限<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="/procedure/approve/<?php echo QUERY_STRING;?>
">批准流程(未)</a></li>						
						</ul>
						</li>
						<?php }?>
						
						<?php if ($_smarty_tpl->tpl_vars['user_info']->value[0]['is_admin'] || $_smarty_tpl->tpl_vars['user_info']->value[0]['is_masterteacher']) {?>
						<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">教导主任权限<b class="caret"></b></a>
						<ul class="dropdown-menu">						
							<li><a href="/procedure/review/<?php echo QUERY_STRING;?>
">审批流程（未）</a></li>						
						</ul>
						</li>
						<?php }?>
						
						<?php if ($_smarty_tpl->tpl_vars['user_info']->value[0]['is_admin'] || $_smarty_tpl->tpl_vars['user_info']->value[0]['is_headteacher']) {?>
						<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">班主任权限<b class="caret"></b></a>
						<ul class="dropdown-menu">						
							<li><a href="/college/class_add/<?php echo QUERY_STRING;?>
">创建班级(未)</a></li>
							<li class="divider"></li>
							<li><a href="/college/class_mate/<?php echo QUERY_STRING;?>
">纳入学员（未）</a></li>
							<!-- <li class="divider"></li> -->
							<!-- <li><a href="#">班级二维码</a></li> -->
						</ul>
						</li>
						<?php }?>
						
						<?php if ($_smarty_tpl->tpl_vars['user_info']->value[0]['is_admin'] || $_smarty_tpl->tpl_vars['user_info']->value[0]['is_teacher']) {?>
						<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">教师权限<b class="caret"></b></a>
						<ul class="dropdown-menu">					
							<li><a href="/college/course_manager/<?php echo QUERY_STRING;?>
">课程管理</a></li>														
							<li class="divider"></li>
							<li><a href="/question/question_list/<?php echo QUERY_STRING;?>
">创建题库(未)</a></li>
							<li class="divider"></li>
							<li><a href="/question/question/<?php echo QUERY_STRING;?>
">添加题目（未）</a></li>
							<li class="divider"></li>
							<li><a href="/exam/exam_list/<?php echo QUERY_STRING;?>
">创建试卷（未）</a></li>
						</ul>
						</li>
						<?php }?>
						
						
						<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">学生权限<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="/exam/study/<?php echo QUERY_STRING;?>
">参加培训（未）</a></li>
							<li class="divider"></li>
							<li><a href="/exam/practice_list/<?php echo QUERY_STRING;?>
">参加练习（未）</a></li>
							<!-- <li class="divider"></li> -->
							<!-- <li><a href="#">参加考试</a></li> -->
							<!-- <li class="divider"></li> -->
							<!-- <li><a href="#">我的成绩</a></li> -->
							<!-- <li class="divider"></li> -->
							<!-- <li><a href="#">我的证书</a></li> -->
						</ul>
						</li>
						
						<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">个人信息<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<!-- <li><a href="#">订单信息</a></li> -->
							<!-- <li class="divider"></li> -->
							<!-- <li><a href="#">个人信息</a></li> -->
							<!-- <li class="divider"></li> -->
							<!-- <li><a href="#">切换身份</a></li> -->
							<!-- <li class="divider"></li> -->
							<li><a href="/user/logout/<?php echo QUERY_STRING;?>
"><span class="glyphicon glyphicon-log-in"></span> 退出登陆</a></li> 
						</ul>
						</li>
						
					</ul>
				</div>
			</div>
		</nav>
	 </div>
	</div>



<?php }
}
