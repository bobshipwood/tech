<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-02 15:18:27
  from 'E:\zhxt\public\statistic\smarty\template\procedure\approve.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5cb3431c9301_10628672',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1cc82259363c6a9a596f5e521f8a6ab4b3cbd967' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\procedure\\approve.html',
      1 => 1582530399,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5cb3431c9301_10628672 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"添加页"), 0, false);
?>
	
	<div class="row">
	 
	 <div class="col-md-2 hidden-xs"></div>
	 
	 <div class="col-md-8 col-xs-12">
		<p class="text-success visible-xs-block">左右滑动一下以便操作</p>
		<div class="table-responsive">
		  <table class="table table-striped table-bordered table-hover table-condensed">
		 
		  <thead>
			<tr>
			  <th>名称</th>
			  <th>申请人</th>
			  <th>学校</th>
			  <th>审批人</th>
			  <th>审批</th>
			  <th>批准人</th>
			  <th>批准</th>
			  <th>操作</th></tr>
		  </thead>
		  <tbody>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['class']->value, 'classes');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['classes']->value) {
?>
			<tr>
			  <form method="POST" >
			  <td><?php echo $_smarty_tpl->tpl_vars['classes']->value['classname'];?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['these']->value->get_name($_smarty_tpl->tpl_vars['classes']->value['creater_id']);?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['these']->value->get_school($_smarty_tpl->tpl_vars['classes']->value['school_id']);?>
</td>
			  <td>
				<?php if (empty($_smarty_tpl->tpl_vars['classes']->value['review_id'])) {?>
					无
				<?php } else { ?>
					<?php echo $_smarty_tpl->tpl_vars['these']->value->get_name($_smarty_tpl->tpl_vars['classes']->value['review_id']);?>

				<?php }?>
			  </td>
			  <td>
				<?php if (empty($_smarty_tpl->tpl_vars['classes']->value['review'])) {?>
					未审批
				<?php } else { ?>
					已审批
				<?php }?>
			  </td>
			  <td>
				<?php if (empty($_smarty_tpl->tpl_vars['classes']->value['approve_id'])) {?>
					无
				<?php } else { ?>
					<?php echo $_smarty_tpl->tpl_vars['these']->value->get_name($_smarty_tpl->tpl_vars['classes']->value['approve_id']);?>

				<?php }?>
			  </td>
			  <td>
				<?php if (empty($_smarty_tpl->tpl_vars['classes']->value['approve'])) {?>
					未批准
				<?php } else { ?>
					已批准
				<?php }?>
			  </td>
			  <td>
			  <input type="hidden" name = "id" value = "<?php echo $_smarty_tpl->tpl_vars['classes']->value['id'];?>
">
			  <button type="submit" class="btn btn-success">批准</button>
			  </form>
			  </td>
			</tr>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
			
		  </tbody>
		</table>
		</div>
		</div>
	 
	 <div class="col-md-2 hidden-xs"></div>
	
	</div>
	
	<div class="row">
      <div class="col-md-12 col-xs-12">
		<?php echo $_smarty_tpl->tpl_vars['paging']->value;?>

	  </div>    
	</div>
	
	


<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
