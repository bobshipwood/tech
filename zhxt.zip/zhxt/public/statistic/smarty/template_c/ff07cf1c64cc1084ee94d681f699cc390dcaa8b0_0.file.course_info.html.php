<?php
/* Smarty version 3.1.34-dev-7, created on 2020-03-02 15:18:37
  from 'E:\zhxt\public\statistic\smarty\template\college\course_info.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e5cb34d181337_27158459',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ff07cf1c64cc1084ee94d681f699cc390dcaa8b0' => 
    array (
      0 => 'E:\\zhxt\\public\\statistic\\smarty\\template\\college\\course_info.html',
      1 => 1582530416,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../header.html' => 1,
    'file:../footer.html' => 1,
  ),
),false)) {
function content_5e5cb34d181337_27158459 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:../header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('title'=>"添加页"), 0, false);
?>
	
	<div class="row" >
	 
	 <div class="col-md-3 hidden-xs"></div>
	 
	 <div class="col-md-6 col-xs-12">
		<p class="text-success visible-xs-block">左右滑动一下以便操作</p>
		<div class="table-responsive">
		  <table class="table table-striped table-bordered table-hover table-condensed">
		  
		  <thead>
			<tr>
			  <th>名称</th>
			  <th>申请人</th>
			  <th>学校</th>
			  <th>操作</th></tr>
		  </thead>
		  <tbody>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['class']->value, 'classes');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['classes']->value) {
?>
			<tr>
			  <td><?php echo $_smarty_tpl->tpl_vars['classes']->value['classname'];?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['these']->value->get_name($_smarty_tpl->tpl_vars['classes']->value['creater_id']);?>
</td>
			  <td><?php echo $_smarty_tpl->tpl_vars['these']->value->get_school($_smarty_tpl->tpl_vars['classes']->value['school_id']);?>
</td>
			  <td>
			  <a class="btn btn-sm btn-info" href="
				<?php if (empty($_GET['c_id'])) {?>
					/college/course_add/<?php echo QUERY_STRING;?>
&c_id=<?php echo $_smarty_tpl->tpl_vars['classes']->value['id'];?>

				<?php } else { ?>
					/college/course_add/<?php echo $_smarty_tpl->tpl_vars['these']->value->replace_query('c_id',$_smarty_tpl->tpl_vars['classes']->value['id']);?>

				<?php }?>
			  " role="button">创建课程</a>
			  
			  </td>
			</tr>
			<?php
}
} else {
?>
			没有数据
			<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
			
		  </tbody>
		</table>
		</div>
		</div>
	 
	 <div class="col-md-3 hidden-xs"></div>
	
	</div>
	
	<div class="row">
      <div class="col-md-12 col-xs-12">
		<?php echo $_smarty_tpl->tpl_vars['paging']->value;?>

	  </div>    
	</div>
	
	


<?php $_smarty_tpl->_subTemplateRender("file:../footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
