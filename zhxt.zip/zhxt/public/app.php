<?php
define(SITE_ROOT,dirname(dirname(__FILE__)).DIRECTORY_SEPARATOR);
define(SMARTY,dirname(__FILE__).DIRECTORY_SEPARATOR.'statistic'.DIRECTORY_SEPARATOR.'smarty'.DIRECTORY_SEPARATOR);
define(QUERY_STRING,'?'.$_SERVER['QUERY_STRING']);

//composer的一小步，php学习路径的一大步.已经在json文件中定义好路径及命名空间的对应关系
require '..'.DIRECTORY_SEPARATOR.'vendor/autoload.php';
use src\response;
use src\logger;
use src\factory;
use src\register;

//以下是加载初始化配置文件
require SITE_ROOT."setup".DIRECTORY_SEPARATOR."config.php";
require SITE_ROOT."setup".DIRECTORY_SEPARATOR."database.php";
require SITE_ROOT."setup".DIRECTORY_SEPARATOR."apierrorcode.php";

factory::getmaindb($database['main']);//工程模式调用主数据库，db1
//factory::getforegindb($database['foregin']);
factory::getsmarty();//smarty调用
factory::getredis($database['redis']);//redis调用

//register::get('db1');注册器模式


$str = bob_input($_SERVER['REQUEST_URI']);

$str = ltrim($str,'/');//去掉最左侧的/

$param = explode('/',$str);//定义接收数组

$qiandao = "\\modules\\admin\\";//表示加载前导类
	
$objectname = $qiandao.$param[0];

$object = new $objectname(register::get('db1'),register::get('smarty'),register::get('redis'),$apierrorcode);//创建api传进来的对象，连接意式正式数据库
		
if(method_exists($object,$param[1])){
	
	call_user_func(array($object, $param[1]));

}else{
	
	echo response::json(40003,$apierrorcode['40003']);
	
}
	
exit;








?>