<?php

$database = array (
	'main' => array (
		'hostname' => 'localhost',
		'port' => 3306,
		'database' => 'test_gdhse_com',
		'username' => 'test_gdhse_com',
		'password' => 'test_gdhse_com',
	),
	'foregin' => array (
		'hostname' => 'localhost',
		'port' => 3306,
		'database' => 'mysql',
		'username' => 'root',
		'password' => 'root',
	),
	'redis' => array (
		'hostname' => '127.0.0.1',
		'port' => 6379,
	)
	
);

?>