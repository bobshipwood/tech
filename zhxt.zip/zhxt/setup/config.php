<?php

//以下设置编码为utf-8 
header("Content-type:text/html;charset=utf-8");

//以下是设置时区为中国时区
date_default_timezone_set('PRC');

//以下是注册错误处理函数
set_error_handler(my_error_report_func);
function my_error_report_func($type,$mess,$file,$line){
    //$str = "自定义出错类型：".$type."<br>出错消息：".$mess."<br>出错文件".$file."<br>出错位置".$line;
    //var_dump($str);
	//exit;
	
	//将所有错误信息归类为异常
    $str = "错误级别：".$type."<br>出错消息：".$mess."<br>出错文件:".$file."<br>出错位置".$line;
	
	throw new Exception($str);   

}


//以下是注册异常处理函数,设置顶层异常处理器 Top Level Exception Handler
set_exception_handler('my_exception_func');
function my_exception_func($exception)
{
	var_dump("<b>手动抛异常: " . '文件名'.$exception->getFile().'   message   '.$exception->getMessage()  .'   行数   '. $exception->getLine().'</b>');
	
}
//throw new Exception("Top Level Exception Handler");上面的代码中，触发顶层的异常处理程序。捕获所有未被捕获的异常。



//在runtime结束时候，调用本方法，利用error_get_last,可以得到错误信息
//只在parse-time出错时是不会调用本函数的。只有在run-time出错的时候，才会调用本函数
//register_shutdown_function('my_shutdown_func');
function my_shutdown_func()
{
	if ($error = error_get_last()) {
        //var_dump('<b>register_shutdown_function: Type:' . $error['type'] . ' Msg: ' . $error['message'] . ' in ' . $error['file'] . ' on line ' . $error['line'] . '</b>');
		var_dump($error);
	}
}












?>