<?php

$apierrorcode['40000'] = 'exception happend,please contact administrator';
$apierrorcode['40001'] = 'url do not include <> etc.';
$apierrorcode['40002'] = 'do not include class file ';
$apierrorcode['40003'] = 'do not find function';
$apierrorcode['40004'] = 'telphonenum has played';
$apierrorcode['40005'] = 'can not find activitydate or activityorder';
$apierrorcode['40006'] = 'can not find station id';
$apierrorcode['20000'] = 'successful connected';

?>