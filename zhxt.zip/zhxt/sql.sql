-- MySQL dump 10.13  Distrib 5.6.45, for Win64 (x86_64)
--
-- Host: localhost    Database: test_gdhse_com
-- ------------------------------------------------------
-- Server version	5.6.45-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `test_gdhse_com`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `test_gdhse_com` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `test_gdhse_com`;

--
-- Table structure for table `yd_class`
--

DROP TABLE IF EXISTS `yd_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yd_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classname` varchar(255) NOT NULL DEFAULT '' COMMENT '班级名称',
  `creater_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '申请人id',
  `school_id` int(10) unsigned NOT NULL COMMENT '学校id',
  `approve` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '批准班级',
  `approve_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '批准人id',
  `review` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '审核班级',
  `review_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '审核人id',
  `teacher` varchar(255) NOT NULL DEFAULT '' COMMENT '任课老师',
  PRIMARY KEY (`id`),
  KEY `school_id` (`school_id`),
  CONSTRAINT `school_id` FOREIGN KEY (`school_id`) REFERENCES `yd_school` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COMMENT='班级表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yd_class`
--

LOCK TABLES `yd_class` WRITE;
/*!40000 ALTER TABLE `yd_class` DISABLE KEYS */;
INSERT INTO `yd_class` VALUES (6,'新冠肺炎的防治--第一期',2,1,1,2,1,7,'伍总');
/*!40000 ALTER TABLE `yd_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yd_course`
--

DROP TABLE IF EXISTS `yd_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yd_course` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `class_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '原先是对应yd_class的id,现在因脑残boss影响，没有作用了',
  `url` varchar(255) NOT NULL COMMENT '课程url',
  `create_date` int(10) unsigned NOT NULL DEFAULT '0',
  `create_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建人id',
  `school_id` int(10) unsigned NOT NULL COMMENT '对应yd_school的id',
  PRIMARY KEY (`id`),
  KEY `class_id` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COMMENT='课程表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yd_course`
--

LOCK TABLES `yd_course` WRITE;
/*!40000 ALTER TABLE `yd_course` DISABLE KEYS */;
INSERT INTO `yd_course` VALUES (3,'第1课',6,'https://r.zhixueyun.com/health/#/play/1',1582274326,2,1),(4,'第2课',6,'https://r.zhixueyun.com/health/#/play/2',1582274352,2,1),(5,'第3课',6,'https://r.zhixueyun.com/health/#/play/3',1582274365,2,1),(6,'第4课',6,'https://r.zhixueyun.com/health/#/play/4',1582274376,2,1),(7,'第5课',6,'https://r.zhixueyun.com/health/#/play/5',1582274387,2,1),(14,'课程',6,'www.baidu.com',1583226906,2,1),(23,'111',0,'222',1583233358,2,1),(24,'存储',0,'www。',1583235438,17,1);
/*!40000 ALTER TABLE `yd_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yd_exam`
--

DROP TABLE IF EXISTS `yd_exam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yd_exam` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `c_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '对应class的id',
  `school_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT ' 对应学校的id',
  `creater_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '试卷名称',
  `dead_line` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '考试时间，分钟为单位',
  `pass_line` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '及格分数线',
  `radio_set` varchar(255) NOT NULL DEFAULT '' COMMENT '单选题的题库类别',
  `radio_point` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '设置单选题的总分',
  `radio_num` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '设置单选题的题目数',
  `checkbox_set` varchar(255) NOT NULL DEFAULT '' COMMENT '多选题的题库类别',
  `checkbox_point` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '设置多选题的总分',
  `checkbox_num` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '设置多选题的题目数',
  `start_time` datetime DEFAULT NULL COMMENT '考试开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '考试结束时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yd_exam`
--

LOCK TABLES `yd_exam` WRITE;
/*!40000 ALTER TABLE `yd_exam` DISABLE KEYS */;
INSERT INTO `yd_exam` VALUES (3,6,1,2,'测试试卷',10,60,'[\"7\"]',30,3,'[\"8\",\"10\"]',70,7,'2020-02-27 15:32:42','2020-02-29 15:32:47'),(4,6,1,2,'只有单选题的试卷',10,60,'[\"7\",\"9\"]',100,10,'',0,0,'2020-02-28 11:20:45','2020-03-11 15:33:00'),(5,6,1,2,'只有多选题的试卷',10,60,'',0,0,'[\"8\",\"10\"]',100,10,'2020-02-17 15:32:52','2020-02-29 15:32:56'),(6,6,1,2,'单+多测试试卷',12,60,'[\"7\",\"9\"]',40,4,'[\"8\",\"10\"]',60,6,'2020-02-25 11:30:00','2020-02-28 22:55:00');
/*!40000 ALTER TABLE `yd_exam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yd_permission`
--

DROP TABLE IF EXISTS `yd_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yd_permission` (
  `id` tinyint(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '拟对应一级菜单的父id，对应本表的id',
  `name` varchar(255) NOT NULL DEFAULT '',
  `controller` varchar(255) NOT NULL DEFAULT '',
  `permission` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yd_permission`
--

LOCK TABLES `yd_permission` WRITE;
/*!40000 ALTER TABLE `yd_permission` DISABLE KEYS */;
INSERT INTO `yd_permission` VALUES (1,0,'添加用户','user','/user/user_add/'),(3,0,'角色权限设置','user','/user/user_permission/'),(4,0,'审批权限','procedure','/procedure/review/'),(5,0,'批准权限','procedure','/procedure/approve/'),(6,0,'添加班级','college','/college/class_add/'),(7,0,'班级学员管理','college','/college/class_mate/');
/*!40000 ALTER TABLE `yd_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yd_question_class`
--

DROP TABLE IF EXISTS `yd_question_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yd_question_class` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classname` varchar(255) NOT NULL DEFAULT '',
  `creater_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建题库人id',
  `school_id` int(10) unsigned NOT NULL DEFAULT '0',
  `class_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '班级的id',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '1为单选，2为多选',
  PRIMARY KEY (`id`),
  KEY `cid` (`class_id`),
  KEY `sid` (`school_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yd_question_class`
--

LOCK TABLES `yd_question_class` WRITE;
/*!40000 ALTER TABLE `yd_question_class` DISABLE KEYS */;
INSERT INTO `yd_question_class` VALUES (7,'肺炎防治---单选题库',2,1,6,1),(8,'肺炎---多选题库',2,1,6,2),(9,'单选题库2---单选题库',2,1,6,1),(10,'多选题库2---多选题库',2,1,6,2);
/*!40000 ALTER TABLE `yd_question_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yd_question_list`
--

DROP TABLE IF EXISTS `yd_question_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yd_question_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `q_id` int(10) unsigned NOT NULL COMMENT '题目类型，对应着yd_question_class的id',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '题目描述',
  `answer_list` text NOT NULL COMMENT '这块存放选择题的选项',
  `correct_answer` text NOT NULL COMMENT '正确答案',
  `school_id` int(10) unsigned NOT NULL,
  `creater_id` int(10) unsigned NOT NULL,
  `class_id` int(10) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '题目类型,1为单选，2为多选',
  PRIMARY KEY (`id`),
  KEY `qid` (`q_id`),
  KEY `cid` (`class_id`),
  KEY `sid` (`school_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yd_question_list`
--

LOCK TABLES `yd_question_list` WRITE;
/*!40000 ALTER TABLE `yd_question_list` DISABLE KEYS */;
INSERT INTO `yd_question_list` VALUES (1,7,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(3,8,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"B\",\"C\"]',1,2,6,2),(4,10,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"C\",\"D\"]',1,2,6,2),(5,7,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(6,7,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(7,7,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(8,7,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(9,7,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(10,7,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(11,7,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(12,7,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(13,7,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(14,9,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(15,9,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(16,9,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(17,9,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(18,9,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1),(19,8,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"B\",\"C\"]',1,2,6,2),(20,8,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"B\",\"C\"]',1,2,6,2),(21,8,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"B\",\"C\"]',1,2,6,2),(22,8,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"B\",\"C\"]',1,2,6,2),(23,8,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"B\",\"C\"]',1,2,6,2),(24,8,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"B\",\"C\"]',1,2,6,2),(25,10,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"C\",\"D\"]',1,2,6,2),(26,10,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"C\",\"D\"]',1,2,6,2),(27,10,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"C\",\"D\"]',1,2,6,2),(28,10,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"C\",\"D\"]',1,2,6,2),(29,10,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"C\",\"D\"]',1,2,6,2),(30,10,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"C\",\"D\"]',1,2,6,2),(31,10,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','[\"A\",\"C\",\"D\"]',1,2,6,2),(33,7,'老年人和儿童在应用抗菌药时，最安全的品种是()','[\"抽象概括能力开始发展。\",\"思维带有直觉行动性。\",\"思维具体形象。\",\"个性特征萌发。\",\"\",\"\",\"\"]','\"A\"',1,2,6,1);
/*!40000 ALTER TABLE `yd_question_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yd_role`
--

DROP TABLE IF EXISTS `yd_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yd_role` (
  `id` tinyint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yd_role`
--

LOCK TABLES `yd_role` WRITE;
/*!40000 ALTER TABLE `yd_role` DISABLE KEYS */;
INSERT INTO `yd_role` VALUES (1,'信息人员'),(2,'校长'),(3,'教导主任'),(4,'班主任'),(5,'普通人员');
/*!40000 ALTER TABLE `yd_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yd_role_permission`
--

DROP TABLE IF EXISTS `yd_role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yd_role_permission` (
  `r_id` tinyint(3) unsigned NOT NULL COMMENT 'yd_role的id',
  `p_id` tinyint(3) unsigned NOT NULL COMMENT 'yd_permission的id',
  PRIMARY KEY (`r_id`,`p_id`) USING BTREE,
  KEY `permission` (`p_id`),
  CONSTRAINT `permission` FOREIGN KEY (`p_id`) REFERENCES `yd_permission` (`id`),
  CONSTRAINT `role` FOREIGN KEY (`r_id`) REFERENCES `yd_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='权限角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yd_role_permission`
--

LOCK TABLES `yd_role_permission` WRITE;
/*!40000 ALTER TABLE `yd_role_permission` DISABLE KEYS */;
INSERT INTO `yd_role_permission` VALUES (1,1);
/*!40000 ALTER TABLE `yd_role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yd_school`
--

DROP TABLE IF EXISTS `yd_school`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yd_school` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '1为企业，2为集团，3为行业',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='学校表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yd_school`
--

LOCK TABLES `yd_school` WRITE;
/*!40000 ALTER TABLE `yd_school` DISABLE KEYS */;
INSERT INTO `yd_school` VALUES (1,'雅皓培训学校',1);
/*!40000 ALTER TABLE `yd_school` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yd_user`
--

DROP TABLE IF EXISTS `yd_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yd_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `salt` char(6) NOT NULL DEFAULT '',
  `role` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '角色的权限',
  `school_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联yd_school的id',
  `is_schoolmaster` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否校长',
  `is_masterteacher` tinyint(3) unsigned NOT NULL COMMENT '是否教导主任',
  `is_headteacher` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否班主任',
  `is_teacher` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否老师',
  `is_admin` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否超级管理员',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `roles` (`role`),
  CONSTRAINT `roles` FOREIGN KEY (`role`) REFERENCES `yd_role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COMMENT='总用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yd_user`
--

LOCK TABLES `yd_user` WRITE;
/*!40000 ALTER TABLE `yd_user` DISABLE KEYS */;
INSERT INTO `yd_user` VALUES (2,'admin','c78efc24057e14c2603dd41b50e90731','t81280',1,1,0,0,0,0,1),(11,'郑兆伟','805f9f981ce861caeab73d8d2ed2696e','t81280',1,1,1,0,0,0,0),(15,'校长','c78efc24057e14c2603dd41b50e90731','t81280',2,1,1,0,1,0,0),(16,'教导主任','c78efc24057e14c2603dd41b50e90731','t81280',3,1,0,1,0,0,0),(17,'老师','c78efc24057e14c2603dd41b50e90731','t81280',4,1,0,0,0,1,0),(18,'班主任','c78efc24057e14c2603dd41b50e90731','t81280',5,1,0,0,1,0,0);
/*!40000 ALTER TABLE `yd_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yd_user_class`
--

DROP TABLE IF EXISTS `yd_user_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yd_user_class` (
  `c_id` int(10) unsigned NOT NULL COMMENT 'class的id',
  `u_id` int(10) unsigned NOT NULL COMMENT 'user的id',
  PRIMARY KEY (`c_id`,`u_id`),
  KEY `userid` (`u_id`),
  CONSTRAINT `classid` FOREIGN KEY (`c_id`) REFERENCES `yd_class` (`id`),
  CONSTRAINT `userid` FOREIGN KEY (`u_id`) REFERENCES `yd_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yd_user_class`
--

LOCK TABLES `yd_user_class` WRITE;
/*!40000 ALTER TABLE `yd_user_class` DISABLE KEYS */;
INSERT INTO `yd_user_class` VALUES (6,2),(6,11),(6,15),(6,16),(6,17),(6,18);
/*!40000 ALTER TABLE `yd_user_class` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-03 19:38:43
