<?php
namespace src;

class register
{
    protected static $objects = [];
   
    public function __construct(){}
    
   
    private function __clone() {}
    
    
    public static function get($alias)
    {
		if(isset(self::$objects[$alias])){
			return self::$objects[$alias];
		}else{
			return false;
		}	
    }
	
	public static function set($alias,$object)
    {
		self::$objects[$alias] = $object;			
    }
	
	public static function destroy($alias)
    {
		unset(self::$objects[$alias]);
    }
      
    public function __destruct(){} 
 
}



?>