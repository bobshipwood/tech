<?php
namespace src;

class pdoobj
{
    protected static $_instance = null;
    protected $dsn;
    protected $dbh;
    protected $stmt;
    /**
     * 构造
     * 
     * @return DAOPDO
     */
    private function __construct($dbHost, $dbUser, $dbPasswd, $dbName)
    {
        try {
            
            $this->dsn = 'mysql:host='.$dbHost.';dbname='.$dbName;
			
            $this->dbh = new \PDO($this->dsn, $dbUser, $dbPasswd,array(\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,\PDO::ATTR_PERSISTENT => false,\PDO::ATTR_STRINGIFY_FETCHES=>false,\PDO::ATTR_EMULATE_PREPARES=>false));
			
			$this->dbh->exec("SET character_set_connection='utf8mb4', character_set_results='utf8mb4', character_set_client=utf8mb4");

        } catch (\PDOException $e) {
           
            die ("Error!: " . $e->getMessage() . "<br/>");
        }
    }
    
    /**
     * 防止克隆
     * 
     */
    private function __clone() {}
    
    /**
     * Singleton instance
     * 
     * @return Object
     */
    public static function getInstance($database)
    {
        if (self::$_instance === null) {
            self::$_instance = new self($database['hostname'], $database['username'], $database['password'], $database['database']);
        }
        return self::$_instance;
    }
	

    /**
     *
     * sql sql语句
     * array execute的数组[]
     * @return 2维数组
     */
    public function select($sql,$array=[]){

    	$this->stmt = $this->dbh->prepare($sql);

		$this->stmt->execute($array);

		$result = $this->stmt->fetchAll(\PDO::FETCH_ASSOC);

    	return $result;
    	
    }

    /**
     *
     * sql sql语句
     * array execute的数组[]
     * @return 2维数组
     */
    public function update($sql,$array=[]){

    	$this->stmt = $this->dbh->prepare($sql);

		$this->stmt->execute($array);

    	return $this->stmt->rowCount(); 	
    	
    }
	
	/**
     *
     * sql sql语句
     * array execute的数组[]
     * @return 2维数组
     */
    public function insert($sql,$array=[]){

    	$this->stmt = $this->dbh->prepare($sql);
		
		$this->stmt->execute($array);		

    	return $this->dbh->lastInsertId();
    	
    }
	


	/**
     *
     * 分页
	 * $items 每页条数
	 * $sql1 求总数的sql语句
     * @return 整个分页
     */
	public function paging($sql1,$item){
		
		$total = $this->select($sql1);
		
		if($total[0]['count']<=0){
			
			exit('没有总数');
		
		}
		
		$total = $total[0]['count'];
		
		$total_page = $total/$item;//求出总页数
		
		if(!is_int($total_page)){
		
			$total_page = intval($total_page)+1;

		}
		
		//获取当前url
		$url = $_SERVER["REQUEST_SCHEME"].'://'.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];  
		
		//判断要在url后面加的？还是&
		if(strpos($url, '?')){
			
			$connector = '&page=';
		
		}else{
		
			$connector = '?page=';

		}
					
		//首页
		
		$url_head_link = isset($_GET['page']) && intval($_GET['page']) ? preg_replace("/page=\d*/",'page=1',$url)  : $url.$connector.'1';
		
		$url_head = "<nav aria-label='Page navigation' style='text-align: center;'>
		  <ul class='pagination'>
			<li>
			  <a href='{$url_head_link}' aria-label='Previous'>
				<span aria-hidden='true'>&laquo;</span>
			  </a>
			</li>";
					
		//中间所有页	
		$url_mid = '';
		
		for($i=1;$i<=$total_page;$i++){
			$url_mid_link = isset($_GET['page']) && intval($_GET['page']) ? preg_replace("/page=\d*/",'page='.$i,$url)  : $url.$connector.$i;
			$url_mid .= "<li><a href='{$url_mid_link}'>{$i}</a></li>";
		}
		
		//尾页
		$url_footer_link = isset($_GET['page']) && intval($_GET['page']) ? preg_replace("/page=\d*/",'page='.$total_page,$url)  : $url.$connector.$total_page;
		
		$url_footer = "<li>
			  <a href='{$url_footer_link}' aria-label='Next'>
				<span aria-hidden='true'>&raquo;</span>
			  </a>
			</li>
		  </ul>
		</nav>";

		$url_foo = 	$url_head.$url_mid.$url_footer;
		
		return $url_foo;
					
	}


	/**
     *
     * 分页数据
	 * $items 每页条数
	 * SQL2 实际数据语句
     * @return 实际数据
     */
	public function page_data($sql2,$item)
    {
        $page = isset($_GET['page']) && intval($_GET['page']) ? intval($_GET['page']) : 1;
		
		$page = $page - 1;//第几页
		
		if($page<0){
			exit('page不能小于0');
		}
		
		$page_start = $page*$item;
			
		$sql2_full = $sql2." limit {$page_start},{$item}";
		
		$data = $this->select($sql2_full);
		
		return $data;
    }

    /**
     * beginTransaction 事务开始
     */
    public function beginTransaction()
    {
        $this->dbh->beginTransaction();
    }
    
    /**
     * commit 事务提交
     */
    public function commit()
    {
        $this->dbh->commit();
    }
    
    /**
     * rollback 事务回滚
     */
    public function rollback()
    {
        $this->dbh->rollback();
    } 
   

    public function __destruct()
    {
    	$this->stmt = null;
    	$this->dbh = null;
    } 
 
}



?>