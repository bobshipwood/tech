<?php

namespace src;

class Response
{

    public static function json($code,$message='',$data=array()){
		
		if(!is_numeric($code)){
			return '';
		}

        $result = array(
            'code'    => $code,
            'message' => $message,
            'data'    => $data
        );

        return json_encode($result);

    }
	
	public static function json1($code,$message='',$data=array()){
		
		if(!is_numeric($code)){
			return '';
		}

        $result = array(
            'code'    => $code,
            'message' => $message,
            'data'    => $data
        );

        return json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

    }
	
}


?>