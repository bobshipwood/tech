<?php
namespace src;

class oauth
{
    private $appid;
    
	private $appsecret;
    
	private $access_token;
	
	private $pdo;
	
    //构造函数，获取Access Token
    public function __construct($database)
    {
	   	
       $this->pdo = $database;
	   
	   $result = $this->pdo->execall('select * from wechat where id = 1');//当当饭堂的公众号
	   
	   $this->appid = $result[0]["APPID"];
	   
	   $this->appsecret = $result[0]["APPSECRET"];
       
	   $this->access_token = $result[0]["access_token"];//全局access_token
	   
	   $result = $this->pdo->execall('select * from wechat where id = 2');//第3方平台
	   
	   $this->component_appid = $result[0]['APPID'];
	   
	   $this->component_access_token = $result[0]['component_access_token'];
         
    }

    //生成OAuth2的URL,拿到code
    public function oauth2_authorize($redirect_url, $scope, $state = NULL)
    {
    
		$url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=".$this->appid."&redirect_uri=".$redirect_url."&response_type=code&scope=".$scope."&state=".$state."#wechat_redirect";
        
		return $url;
    
	}

    //以code换取Access Token,openid
    public function oauth2_access_token($code)
    {
        $url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$this->appid."&secret=".$this->appsecret."&code=".$code."&grant_type=authorization_code";

		$res = $this->http_request($url);
		
        return json_decode($res, true);
    }

    //获取用户基本信息（Access Token由OAuth2授权获取, Access Token为临时获取,其中关注信息与否通过此接口获取不到.）
    public function oauth2_get_user_info($access_token, $openid)
    {
        $url = "https://api.weixin.qq.com/sns/userinfo?access_token=".$access_token."&openid=".$openid."&lang=zh_CN";
        
		$res = $this->http_request($url);
        
		return json_decode($res, true);
    }

    //调用全局获取的access_token及网页授权的openid,来获取用户基本信息（包含关注）
    public function get_user_info($openid)
    {
        $url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=".$this->access_token."&openid=".$openid."&lang=zh_CN";
        $res = $this->http_request($url);
        return json_decode($res, true);
    }
	
	
	
	

    //HTTP请求（支持HTTP/HTTPS，支持GET/POST）
    protected function http_request($url, $data = null)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        if (!empty($data)){
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }
	
	//第3方授权，获取code
	public function third_oauth2_authorize($redirect_url, $scope, $state = NULL,$appid =NULL){
		
		$url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={$this->appid}&redirect_uri={$redirect_url}&response_type=code&scope={$scope}&state={$state}&component_appid={$this->component_appid}#wechat_redirect";
        
		return $url;
		
	}
	
	 //第3方授权，获取accesstoken，openid,$appid是公众号的appid
    public function third_oauth2_accesstoken($code,$appid=NULL)
    {
        $url = "https://api.weixin.qq.com/sns/oauth2/component/access_token?appid={$this->appid}&code={$code}&grant_type=authorization_code&component_appid={$this->component_appid}&component_access_token={$this->component_access_token}";

		$res = $this->http_request($url);
		
        return json_decode($res, true);
    }
	
	//第3方授权。获取用户基本信息
    public function third_oauth2_getuserinfo($access_token, $openid)
    {
        $url = "https://api.weixin.qq.com/sns/userinfo?access_token={$access_token}&openid={$openid}&lang=zh_CN";
        
		$res = $this->http_request($url);
        
		return json_decode($res, true);
    }

	
	
	
}


?>
