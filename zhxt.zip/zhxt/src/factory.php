<?php
namespace src;

class factory
{
    protected static $_instance = null;

    public function __construct()
    {
        // try {
                 
        // } catch (Exception $e) {
           
            // die ("Error!: " . $e->getMessage() . "<br/>");
        // }
    }
     
    private function __clone() {}
      
    public static function getmaindb($database)
    {	
		register::set('db1',pdoobj::getInstance($database));
    
    }
	
	public static function getforegindb($database)
    {   
        register::set('db2',pdoobj2::getInstance($database));
    }
	
	public static function getsmarty()
    {   
        $smarty = new \Smarty;
		//$smarty->left_delimiter = "{#";
		//$smarty->right_delimiter = "#}";
		$smarty->setTemplateDir(SMARTY.'template'.DIRECTORY_SEPARATOR); //设置模板目录
		$smarty->setCompileDir(SMARTY.'template_c'.DIRECTORY_SEPARATOR);//  设置编译目录
		$smarty->setConfigDir(SMARTY.'config'.DIRECTORY_SEPARATOR);
		$smarty->setCacheDir(SMARTY.'cache'.DIRECTORY_SEPARATOR);//设置缓存目录
		//$smarty->force_compile = true; 强制编译的意思？
		// if (APP_DEBUG) {
			// //$smarty->debugging      = true;//smarty的排除模式开启？
			// $smarty->caching        = false;
			// $smarty->cache_lifetime = 0;
		// } else {
			// //$smarty->debugging      = false;
			// $smarty->caching        = true;
			// $smarty->cache_lifetime = 120;
		// }
		$smarty->caching        = false;
		$smarty->cache_lifetime = 0;
		
		register::set('smarty',$smarty);
		
    }
	
	public static function getredis()
	{
		
		$redis = new \redis();
		
		//$redis->connect('127.0.0.1', 6379);
		call_user_func(array($redis, 'connect'),'127.0.0.1','6379');
		
		$redis->auth('root');
		
		register::set('redis',$redis);
		
	}
      
    public function __destruct(){} 
 
}



?>