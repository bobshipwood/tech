<?php
/**
 *  extention.func.php 用户自定义函数库
 *
 * @copyright			(C) 2005-2010 PHPCMS
 * @license				http://www.phpcms.cn/license/
 * @lastmodify			2010-10-27
 */
 

/**
 * 我写的过滤函数
 *
 * @param $data 输入的信息 利用递归，貌似可以支持多维数组，$k没有过滤
 * @return 返回数组或者字符串
 */
function bob_input($data){

	if(is_array($data)){
	    
		foreach ($data as $k=>$v){

		    $data[$k]=bob_input($v);
		
		}
	    
		return $data;
		
	}else{
		
	    $data = trim($data);
		
	    $data = stripslashes($data);
		
	    $data = htmlspecialchars($data,ENT_QUOTES);
		
	    return $data;
	}
}


/**
 * 我写的打印变量函数
 * @return 打印变量
 */
 function p(){
		
	$num=func_num_args();
	
	$bianliang=func_get_args();

	for($i=0;$i<$num;$i++){
	    
		echo "<pre>";
		
		var_dump($bianliang[$i]);
		
		echo "</pre>";
		
		echo "<br>";
	}

	exit;

}


/**
 * 我写的urlencode过滤函数,用与微信中数组转成json时候有中文的处理。如urldecode(json_encode(urlencode($data))
 *
 * @param $data 可以是数组或字符串，利用递归貌似可以支持多维数组
 * @return 返回数组或者字符串
 */
function url2($data){

  if(is_array($data)){
      
    foreach ($data as $k=>$v){

      if(is_array($v)){

        $data[$k]=url2($v);

      }else{

        $data[$k]= urlencode($v);

      }
    
    }
      
    return $data;
    
  }else{
    
    $data = urlencode($data);
    
    return $data;

  }

}

/**
 * 检测是否是utf-8格式并转为utf8
 * @param  str  utf8 gbk gb2312
 * @return str
 */
function utf8($str){
	//mb_convert_encoding($str, 'html-entities', 'utf-8');转成html编码
	$str = mb_convert_encoding($str, 'utf-8', mb_detect_encoding($str, ['utf-8','gbk','gb2312']));
	return $str;
}



/**
 * 获取请求ip
 *
 * @return ip地址
 */
function ip() {
	if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
		$ip = getenv('HTTP_CLIENT_IP');
	} elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
		$ip = getenv('HTTP_X_FORWARDED_FOR');
	} elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
		$ip = getenv('REMOTE_ADDR');
	} elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
		$ip = $_SERVER['REMOTE_ADDR'];
	}

	//filter_var($ip,FILTER_VALIDATE_IP) && $ip='';
	return preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : '';
}

/**
* 产生随机字符串
*
* @param    int        $length  输出长度
* @param    string     $chars   可选的 ，默认为 0123456789
* @return   string     字符串
*/
function random($length, $chars = '0123456789abcdefghijklmnopqrstuvwxyz') {
	$hash = '';
	$max = strlen($chars) - 1;
	mt_srand();
	for($i = 0; $i < $length; $i++) {
		$hash .= $chars[mt_rand(0, $max)];
	}
	return $hash;
}





?>