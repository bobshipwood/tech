<?php
namespace easys\third;

use easys\web\response;
use easys\web\pdoobj;
use easys\web\oauth;
use easys\web\logger;

use easys\wechat\WXBizMsgCrypt;
use easys\wechat\index3;


class index{
	
	private $pdo = null;
	
	protected $apierrorcode;
	//www.gzfesco.cn/wechat/transfer/authorize
	public function __construct($database,$apierrorcode,$source_appid) {

		header('Access-Control-Allow-Origin:*');
		
		//origin-when-cross-origin
		
		//header('Referrer-Policy: origin-when-cross-origin');
		
		$this->pdo = pdoobj::getInstance($database);
		
		$this->apierrorcode = $apierrorcode;
		
		$result = $this->pdo->execall('select * from wechat where id = 2');
	   
	    $this->component_appid = $result[0]['APPID'];
	   
	    $this->component_appsecret = $result[0]['APPSECRET'];
		
		$this->token = $result[0]['token'];
		
		$this->EncodingAESKey = $result[0]['EncodingAESKey'];
		//前面这4项包括appid等，和微信公众号复用栏位
		$this->component_verify_ticket = $result[0]['component_verify_ticket'];
		
		$this->component_expires_time = $result[0]['component_expires_time'];
		
		$this->component_access_token = $result[0]['component_access_token'];
		//最后一项，用于第3方平台区分公众号的appid
		$this->source_appid = $source_appid;
		
	}
	
	public function __destruct() {
		
	}
	
	
	//http请求
	public function http_request($url, $data = null)
	{
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		if (!empty($data)){
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$output = curl_exec($curl);
		curl_close($curl);
		return $output;
	}
	
	
	//响应消息.
    public function responseMsg()
    {
        $signature  = $_GET['signature'];
		$timestamp  = $_GET['timestamp'];
		$nonce = $_GET['nonce'];
        $encrypt_type = $_GET['encrypt_type'];
		$msg_signature  = $_GET['msg_signature'];
        //$postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
        $postStr= file_get_contents("php://input");
		
		logger::loging('postStr.log',date('Y-m-d H:i:s',time()).$postStr.PHP_EOL);
		
		if (!empty($postStr)){
			//解密
            if ($encrypt_type == 'aes'){
				$pc = new WXBizMsgCrypt($this->token, $this->EncodingAESKey, $this->component_appid);
				
                $decryptMsg = "";  //解密后的明文
                $errCode = $pc->DecryptMsg($msg_signature, $timestamp, $nonce, $postStr, $decryptMsg);
				//logger::loging('errCode.log',$errCode.PHP_EOL);
				$postStr = $decryptMsg;
			}

            
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            $RX_TYPE = trim($postObj->MsgType);

            //消息类型分离
            switch ($RX_TYPE)
            {
                case "event":
                    $result = $this->receiveEvent($postObj);
                    break;
                case "text":
                    $result = $this->receiveText($postObj);
                    break;
                case "image":
                    $result = $this->receiveImage($postObj);
                    break;
                case "location":
                    $result = $this->receiveLocation($postObj);
                    break;
                case "voice":
                    $result = $this->receiveVoice($postObj);
                    break;
                case "video":
                    $result = $this->receiveVideo($postObj);
                    break;
                case "link":
                    $result = $this->receiveLink($postObj);
                    break;
                default:
                    $result = "unknown msg type: ".$RX_TYPE;
                    break;
            }
			//加密
			if ($encrypt_type == 'aes'){
				$encryptMsg = ''; //加密后的密文
				$errCode = $pc->encryptMsg($result, $timestamp, $nonce, $encryptMsg);
				$result = $encryptMsg;
				//logger::loging('errCode.log',$errCode.PHP_EOL);
			}
            echo $result;
        }else {
            echo "";
            exit;
        }
    }

    //接收事件消息
    private function receiveEvent($object)
    {
        $content = "";
        switch ($object->Event)
        {
            case "subscribe":
                $content = "欢迎关注 ";
                $content .= (!empty($object->EventKey))?("\n来自二维码场景 ".str_replace("qrscene_","",$object->EventKey)):"";
                break;
            case "unsubscribe":
                $content = "success";
                break;
            case "CLICK":
                switch ($object->EventKey)
                {
                    case "COMPANY":
                        $content = array();
                        $content[] = array("Title"=>"工作室", "Description"=>"", "PicUrl"=>"http://discuz.comli.com/weixin/weather/icon/cartoon.jpg", "Url" =>"http://m.cnblogs.com/?u=txw1958");
                        break;
                    default:
                        $content = "点击菜单：".$object->EventKey;
                        break;
                }
                break;
            case "VIEW":
                $content = "跳转链接 ".$object->EventKey;
                break;
            case "SCAN":
                $content = "扫描场景 ".$object->EventKey;
                break;
            case "LOCATION":
                // $content = "上传位置：纬度 ".$object->Latitude.";经度 ".$object->Longitude;
                $content = $object->Event."from_callback";
                break;
            case "scancode_waitmsg":
                $content = "扫码带提示：类型 ".$object->ScanCodeInfo->ScanType." 结果：".$object->ScanCodeInfo->ScanResult;
                break;
            case "scancode_push":
                $content = "扫码推事件";
                break;
            case "pic_sysphoto":
                $content = "系统拍照";
                break;
            case "pic_weixin":
                $content = "相册发图：数量 ".$object->SendPicsInfo->Count;
                break;
            case "pic_photo_or_album":
                $content = "拍照或者相册：数量 ".$object->SendPicsInfo->Count;
                break;
            case "location_select":
                $content = "发送位置：标签 ".$object->SendLocationInfo->Label;
                break;
            default:
                $content = "receive a new event: ".$object->Event;
                break;
        }

        if(is_array($content)){
            if (isset($content[0]['PicUrl'])){
                $result = $this->transmitNews($object, $content);
            }else if (isset($content['MusicUrl'])){
                $result = $this->transmitMusic($object, $content);
            }
        }else{
            $result = $this->transmitText($object, $content);
        }
        return $result;
    }

    //接收文本消息
    private function receiveText($object)
    {
        $keyword = trim($object->Content);
		
		//从消息中提取openid
		$openid = strval($object->FromUserName);
		
		//logger::loging('openid.log',$openid.PHP_EOL);
		
        if (strstr($keyword, "TESTCOMPONENT_MSG_TYPE_TEXT")){
            // $content = "这是个文本消息";
            $content = $keyword."_callback";
			
			logger::loging('wechatcallback1.log',$content.PHP_EOL);
			
        }else if(strstr($keyword, "QUERY_AUTH_CODE")){
            $content = "";
            //调用客服接口发送消息
            // <Content><![CDATA[QUERY_AUTH_CODE:queryauthcode@@@vxXY_z946RStZLZQG7oiuiG7CFogny_kI-PJ2f6Mix6D6PmNAGMJ0p_811zAAjHuC-ubEHHLdqom2p6VOp7awg]]></Content>
            $authorization_code = str_replace("QUERY_AUTH_CODE:","",$keyword);
            
            //logger::loging('authorization_code.log',$authorization_code.PHP_EOL);
			
			//这里直接用index3，有无问题？
			$weixin = new index3($this->pdo,$this->apierrorcode);
            
			$authorization = $weixin->query_authorization($authorization_code);
			
            $authorizer_access_token = $authorization["authorization_info"]["authorizer_access_token"];
			
			//logger::loging('authorizer_access_token.log',$authorizer_access_token.PHP_EOL);
           
            $result = $weixin->send_custom_message($openid, "text", $authorization_code."_from_api", $authorizer_access_token);
			
			//logger::loging('result.log',$result.PHP_EOL);
            
        }else{
            $content = date("Y-m-d H:i:s",time())."\n".$object->FromUserName."\n技术支持 工作室";
        }

        if(is_array($content)){
            if (isset($content[0])){
                $result = $this->transmitNews($object, $content);
            }else if (isset($content['MusicUrl'])){
                $result = $this->transmitMusic($object, $content);
            }
        }else{
            $result = $this->transmitText($object, $content);
        }

        return $result;
    }

    //接收图片消息
    private function receiveImage($object)
    {
        $content = array("MediaId"=>$object->MediaId);
        $result = $this->transmitImage($object, $content);
        return $result;
    }

    //接收位置消息
    private function receiveLocation($object)
    {
        $content = "你发送的是位置，经度为：".$object->Location_Y."；纬度为：".$object->Location_X."；缩放级别为：".$object->Scale."；位置为：".$object->Label;
        $result = $this->transmitText($object, $content);
        return $result;
    }

    //接收语音消息
    private function receiveVoice($object)
    {
        if (isset($object->Recognition) && !empty($object->Recognition)){
            $content = "你刚才说的是：".$object->Recognition;
            $result = $this->transmitText($object, $content);
        }else{
            $content = array("MediaId"=>$object->MediaId);
            $result = $this->transmitVoice($object, $content);
        }
        return $result;
    }

    //接收视频消息
    private function receiveVideo($object)
    {
        $content = array("MediaId"=>$object->MediaId, "ThumbMediaId"=>$object->ThumbMediaId, "Title"=>"", "Description"=>"");
        $result = $this->transmitVideo($object, $content);
        return $result;
    }

    //接收链接消息
    private function receiveLink($object)
    {
        $content = "你发送的是链接，标题为：".$object->Title."；内容为：".$object->Description."；链接地址为：".$object->Url;
        $result = $this->transmitText($object, $content);
        return $result;
    }

    //回复文本消息
    private function transmitText($object, $content)
    {
		
		//第3方平台全网发布时候，需要检测该至，去掉这个？
		// if (!isset($content) || empty($content)){
			// return "";
		// }

		$xmlTpl = "<xml>
	<ToUserName><![CDATA[%s]]></ToUserName>
	<FromUserName><![CDATA[%s]]></FromUserName>
	<CreateTime>%s</CreateTime>
	<MsgType><![CDATA[text]]></MsgType>
	<Content><![CDATA[%s]]></Content>
</xml>";
		$result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time(), $content);

        return $result;
    }

    //回复图文消息
    private function transmitNews($object, $newsArray)
    {
        if(!is_array($newsArray)){
            return "";
        }
        $itemTpl = "        <item>
            <Title><![CDATA[%s]]></Title>
            <Description><![CDATA[%s]]></Description>
            <PicUrl><![CDATA[%s]]></PicUrl>
            <Url><![CDATA[%s]]></Url>
        </item>
";
        $item_str = "";
        foreach ($newsArray as $item){
            $item_str .= sprintf($itemTpl, $item['Title'], $item['Description'], $item['PicUrl'], $item['Url']);
        }
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[news]]></MsgType>
    <ArticleCount>%s</ArticleCount>
    <Articles>
$item_str    </Articles>
</xml>";

        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time(), count($newsArray));
        return $result;
    }

    //回复音乐消息
    private function transmitMusic($object, $musicArray)
    {
		if(!is_array($musicArray)){
            return "";
        }
        $itemTpl = "<Music>
        <Title><![CDATA[%s]]></Title>
        <Description><![CDATA[%s]]></Description>
        <MusicUrl><![CDATA[%s]]></MusicUrl>
        <HQMusicUrl><![CDATA[%s]]></HQMusicUrl>
    </Music>";

        $item_str = sprintf($itemTpl, $musicArray['Title'], $musicArray['Description'], $musicArray['MusicUrl'], $musicArray['HQMusicUrl']);

        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[music]]></MsgType>
    $item_str
</xml>";

        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }

    //回复图片消息
    private function transmitImage($object, $imageArray)
    {
        $itemTpl = "<Image>
        <MediaId><![CDATA[%s]]></MediaId>
    </Image>";

        $item_str = sprintf($itemTpl, $imageArray['MediaId']);

        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[image]]></MsgType>
    $item_str
</xml>";

        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }

    //回复语音消息
    private function transmitVoice($object, $voiceArray)
    {
        $itemTpl = "<Voice>
        <MediaId><![CDATA[%s]]></MediaId>
    </Voice>";

        $item_str = sprintf($itemTpl, $voiceArray['MediaId']);
        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[voice]]></MsgType>
    $item_str
</xml>";

        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }

    //回复视频消息
    private function transmitVideo($object, $videoArray)
    {
        $itemTpl = "<Video>
        <MediaId><![CDATA[%s]]></MediaId>
        <ThumbMediaId><![CDATA[%s]]></ThumbMediaId>
        <Title><![CDATA[%s]]></Title>
        <Description><![CDATA[%s]]></Description>
    </Video>";

        $item_str = sprintf($itemTpl, $videoArray['MediaId'], $videoArray['ThumbMediaId'], $videoArray['Title'], $videoArray['Description']);

        $xmlTpl = "<xml>
    <ToUserName><![CDATA[%s]]></ToUserName>
    <FromUserName><![CDATA[%s]]></FromUserName>
    <CreateTime>%s</CreateTime>
    <MsgType><![CDATA[video]]></MsgType>
    $item_str
</xml>";

        $result = sprintf($xmlTpl, $object->FromUserName, $object->ToUserName, time());
        return $result;
    }
	
	public function test(){
		echo date('Y-m-d H:i:s',time());
		//header("Content-type: text/plain;charset=UTF-8");
		phpinfo();
		//p($_SERVER);
		
	}
	

    

}


?>