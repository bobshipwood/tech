<?php
namespace modules\admin;

use src\response;
use src\logger;

class user extends admin 
{
	
	public function __construct($database,$smarty,$redis,$apierrorcode) {
		//header('Content-type: application/json');
		//header('Access-Control-Allow-Origin:*');
		parent::__construct($database,$smarty,$redis,$apierrorcode);
			
	}
	
	public function __destruct() {
		
	}
	
	
	
	public function index()
	{
		if($this->check_login()){
			
			$this->view->assign('user_info',$this->user_info);
		
			$this->view->display('user/index.html');
		}	
	}
	
	//普通登陆
	public function index_normal()
	{
		if($this->check_login()){
			
			$this->view->assign('user_info',$this->user_info);
		
			$this->view->display('user/index_normal.html');
		}	
	}
	
	public function user_add()
	{
		if($this->check_login()){
			
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			
				$username = bob_input($_POST['username']);
				
				$password = bob_input($_POST['password']);
				
				$role = bob_input($_POST['role']);
				
				$school_id = bob_input($_POST['school_id']);
				
				$userinfo = $this->pdo->select("select * from yd_user where username = '{$username}' limit 1 ");
				
				if(empty($userinfo)){
					
					$salt = random(6);
					
					$input_pass = $this->descrypt($password,$salt);
					
					$is_it = $is_schoolmaster = $is_headteacher = $is_teacher=0;
					
					switch($role)
					{
						case '1':
							$is_it = 1;
						break;
						
						case '2':
							$is_schoolmaster = 1;
						break;
						
						case '3':
							$is_headteacher = 1;
						break;
						
						case '4':
							$is_teacher = 1;
						break;					
					}
					
					$sql = "insert into yd_user (`username`,`password`,`salt`,`role`,`school_id`,`is_it`,`is_schoolmaster`,`is_headteacher`,`is_teacher`) values ('{$username}','{$input_pass}','{$salt}',{$role},{$school_id},{$is_it},{$is_schoolmaster},{$is_headteacher},{$is_teacher})";
					
					$id = $this->pdo->insert($sql);
					
					if($id){						
						$this->modal_display('新增用户成功',$this->get_permission(__METHOD__).QUERY_STRING);						
					}else{
						$this->modal_display('新增用户失败',$this->get_permission(__METHOD__).QUERY_STRING);
					}
					
				}else{
					$this->modal_display('你输入的用户名已存在',$this->get_permission(__METHOD__).QUERY_STRING);
				}
			
			}
			
			$roles = $this->pdo->select("select * from yd_role");
			
			$school = $this->pdo->select("select * from yd_school");

			$this->view->assign('role',$roles);
			
			$this->view->assign('school',$school);
			
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->display('user/user_add.html');
			
		}	
	}
	
	
	public function login()
	{
		
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			
			$username = bob_input($_POST['username']);
			
			$password = bob_input($_POST['password']);
			
			$userinfo = $this->pdo->select("select * from yd_user where username = '{$username}' limit 1 ");
			
			if(empty($userinfo)){
				$this->modal_display('你输入的用户名不存在');
			}else{
				
				$descrypt = $this->descrypt($password,$userinfo[0]['salt']);
				
				if($descrypt==$userinfo[0]['password']){
					
					$id = intval($userinfo[0]['id']);
					
					$this->redis->setex($id, 3600*24,"true");
					//登陆页面选择
					if($userinfo[0]['is_admin']==1){
						$this->modal_display('成功登陆',"/user/index/?id={$id}");
					}else{
						
						$this->modal_display('成功登陆',"/user/index_normal/?id={$id}");
					}
					
				}else{
					$this->modal_display('登陆失败');
				}
			}
			
		}
		
		$this->view->display('user/login.html');
	
	}
	
	public function logout()
	{
		if(!empty($_GET['id'])){
			
			$id = $this->get_id();;
			
			$result = $this->redis->del($id);

		}
		if($result){
			$this->modal_display('成功退出');
		}else{
			$this->modal_display('退出异常');
		}
		$this->view->display('user/login.html');
	
	}
	
	public function user_permission()
	{
		
		
		if($this->check_login()){
			
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
				
				$is_schoolmaster = isset($_POST['is_schoolmaster']) ? 1:0;
					
				$is_masterteacher = isset($_POST['is_masterteacher']) ? 1:0;
					
				$is_headteacher = isset($_POST['is_headteacher']) ? 1:0;
					
				$is_teacher = isset($_POST['is_teacher']) ? 1:0;
				
				$id = bob_input($_POST['id']);
				
				$sql = "update yd_user set is_teacher={$is_teacher},is_headteacher={$is_headteacher},is_masterteacher={$is_masterteacher},is_schoolmaster={$is_schoolmaster} where id={$id} ";//拼接sql插入语句
			
				try{
					
					$this->pdo->update($sql);
					
					$this->modal_display('修改成功',$this->get_permission(__METHOD__).QUERY_STRING);
									
				}catch (\PDOException $e) {
					$this->modal_display('有错误发生',$this->get_permission(__METHOD__).QUERY_STRING);
				}
				
			}	
			
			$id = $this->get_id();
			
			$school = $this->pdo->select("select school_id from yd_user where id ={$id} limit 1");
			
			$num = 20;//每页的数量
				
			$sql1 = "select count(id) as count from yd_user where school_id = {$school[0]['school_id']}";
		
			$sql2 = "select * from yd_user where school_id = {$school[0]['school_id']} ";
		
			$info  = $this->paging($num,$sql1,$sql2);
			
			$this->view->assign('info',$info['page_data']);
			
			$this->view->assign('paging',$info['paging']);
			
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->display('user/user_permission.html');
			
		}
		
	
	}
	
	
	
	
	
	
	


}
?>