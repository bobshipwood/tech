<?php
namespace modules\admin;

use src\response;
use src\logger;

class college extends admin 
{
	
	public function __construct($database,$smarty,$redis,$apierrorcode) {
		//header('Content-type: application/json');
		//header('Access-Control-Allow-Origin:*');
		parent::__construct($database,$smarty,$redis,$apierrorcode);
			
	}
	
	public function __destruct() {
		
	}
	
	
	public function class_add(){
		
		if($this->check_login()){
				
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			
				$classname = bob_input($_POST['classname']);
				
				$school_id = bob_input($_POST['school']);
				
				$creater_id = $this->get_id();
				
				$teacher = bob_input($_POST['teacher']);;
				
				$sql = "insert into yd_class (`classname`,`school_id`,`creater_id`,`teacher`) values ('{$classname}',{$school_id},{$creater_id},'{$teacher}')";
				
				$id = $this->pdo->insert($sql);
				
				if($id){					
					$this->modal_display('新增班级成功',$this->get_permission(__METHOD__).QUERY_STRING);	
				}else{
					$this->modal_display('新增班级失败',$this->get_permission(__METHOD__).QUERY_STRING);
				}
							
			}
					
			$school = $this->pdo->select("select * from yd_school");
			$this->view->assign('school',$school);
			$this->view->assign('user_info',$this->user_info);
			$this->view->display('college/class_add.html');
		}
			
	}
	
	//班级学员管理
	public function class_mate(){
		
		if($this->check_login()){
			
			$num = 4;//每页的数量
			
			$id = $this->get_id();
			
			$info1 = $this->pdo->select("select school_id from yd_user where id = {$id} limit 1 ");
			
			$sql1 = "select count(*) as count from yd_class where school_id = {$info1[0]['school_id']}";
		
			$sql2 = "select * from yd_class where school_id = {$info1[0]['school_id']}";
		
			$info  = $this->paging($num,$sql1,$sql2);
			
			$this->view->assign('class',$info['page_data']);
			
			$this->view->assign('paging',$info['paging']);
			
			$this->view->assign('these',$this);
			
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->display('college/class_mate.html');
		
		}
	}
	
	//班级学员管理
	public function classmate_all(){
		
		if($this->check_login()){
			
			$id = $this->get_id();
			
			$c_id = bob_input($_GET['c_id']);
		
			$info1 = $this->pdo->select("select school_id from yd_user where id = {$id} limit 1 ");
		
			$info2 = $this->pdo->select("select id from yd_user where school_id = {$info1[0]['school_id']}");

			$sql = '';
				
			foreach($info2 as $u_id ){
				$sql .= '('.$c_id.','.$u_id['id'].'),';
			}
			
			$sql = rtrim($sql,',');
			
			$sql = 'INSERT INTO yd_user_class VALUES '.$sql;//拼接sql插入语句
			
			try{
				
				$this->pdo->update($sql);
				
				$this->modal_display('已提交','/college/class_mate/'.QUERY_STRING);
								
			}catch (\PDOException $e) {
				$this->modal_display('你提交的名单里已经有人在该班级','/college/class_mate/'.QUERY_STRING);
			}
		
		}
	}
	
	//班级学员管理
	public function classmate_special(){
		
		if($this->check_login()){
			
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
				
				if(empty($_POST['optionsRadios'])){
					$this->modal_display('没选择任何成员',$this->get_permission(__METHOD__).QUERY_STRING);	
				}
				
				$optionsRadios = bob_input($_POST['optionsRadios']);
				
				$c_id = bob_input($_GET['c_id']);
				
				$sql = '';
				
				foreach($optionsRadios as $u_id ){
					$sql .= '('.$c_id.','.$u_id.'),';
				}
				
				$sql = rtrim($sql,',');
				
				$sql = 'INSERT INTO yd_user_class VALUES '.$sql;//拼接sql插入语句
				
				try{
					
					$this->pdo->update($sql);
					
					$this->modal_display('已提交',$this->get_permission(__METHOD__).QUERY_STRING);
									
				}catch (\PDOException $e) {
					$this->modal_display('你提交的名单已经在班级',$this->get_permission(__METHOD__).QUERY_STRING);
				}
				
			}
			
			$array = $this->get_schoolmates();//取得相同学校的人员和分页
			
			$this->view->assign('schoolmate',$array['schoolmates']);
			
			$this->view->assign('paging',$array['paging']);
			
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->display('college/classmate_special.html');
		
		}
	}
	
	
	//班级课程列表2,已经被脑残boss否决了
	public function course_info(){
		
		if($this->check_login()){
			
			$num = 5;//每页的数量
			
			$id = $this->get_id();
			
			$info1 = $this->pdo->select("select school_id from yd_user where id = {$id} limit 1 ");
			
			$sql1 = "select count(*) as count from yd_class where school_id = {$info1[0]['school_id']} and approve = 1";
		
			$sql2 = "select * from yd_class where school_id = {$info1[0]['school_id']} and approve=1";
		
			$info  = $this->paging($num,$sql1,$sql2);
			
			$this->view->assign('class',$info['page_data']);
			
			$this->view->assign('paging',$info['paging']);
			
			$this->view->assign('these',$this);
			
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->display('college/course_info.html');
		
		}
			
	}
	
	//增加课程,原先上一层是course_info
	public function course_add(){
		
		if($this->check_login()){
				
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			
				$name = bob_input($_POST['name']);
				
				$school_id = bob_input($_POST['school']);
				
				$class_id = 0;//先默认都等于0,脑残boss的影响所致
				
				$url = bob_input($_POST['url']);
				
				$create_id = $this->get_id();
				
				$create_date = time();
				
				try{
					
					$sql = "insert into yd_course (`name`,`school_id`,`create_id`,`class_id`,`create_date`,`url`) values ('{$name}',{$school_id},{$create_id},{$class_id},{$create_date},'{$url}')";
				
					$id = $this->pdo->insert($sql);
								
					$this->modal_display('新增课程成功','/college/course_manager/'.QUERY_STRING);	
				
				}catch (\Exception $e){
					
					$this->modal_display('新增课程失败',$this->get_permission(__METHOD__).QUERY_STRING);
				
				}
							
			}
					
			$school = $this->pdo->select("select * from yd_school");
			
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->assign('school',$school);
			
			$this->view->display('college1/course_add.html');
		
		}
			
	}
	
	public function course_update(){
		
		if($this->check_login()){
			
			$id = bob_input($_GET['course_id']);
			
			$info = $this->pdo->select("select * from yd_course where id = {$id} limit 1");
			
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			
				$name = bob_input($_POST['name']);
				
				$url = bob_input($_POST['url']);
				
				try{
					
					$sql = "update yd_course set `name` = '{$name}',`url`='{$url}' where id ={$id}";
					
					$this->pdo->update($sql);
								
					$this->modal_display('修改课程成功','/college/course_manager/'."?id=".$this->get_id());	
				
				}catch (\Exception $e){
					
					$this->modal_display('修改课程失败',$this->get_permission(__METHOD__).QUERY_STRING);
				
				}
							
			}
			
			$this->view->assign('info',$info[0]);
		
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->display('college1/course_update.html');
		
		}
			
	}
	
	//课程列表
	public function course_manager(){
		
		if($this->check_login()){
			
			$id = $this->get_id();
			
			if(isset($_GET['action'])){
				
				if ($_GET['action'] == 'del') {
					
					$course_id = bob_input($_GET['course_id']);
					
					try{
						$this->pdo->update("delete from yd_course where id = {$course_id}");
						$this->modal_display('删除成功',$this->get_permission(__METHOD__)."?id={$id}");			
					}catch (\Exception $e){
						$this->modal_display('删除失败',$this->get_permission(__METHOD__)."?id={$id}");		
					}
				}			
				
			}
			
			
			$num = 5;//每页的数量
			
			$info1 = $this->pdo->select("select school_id from yd_user where id = {$id} limit 1 ");
			
			$sql1 = "select count(*) as count from yd_course where school_id = {$info1[0]['school_id']} and create_id = {$id} order by id desc";
			
			$sql2 = "select * from yd_course where school_id = {$info1[0]['school_id']} and create_id = {$id} order by id desc";
			
			$count = $this->pdo->select($sql1);
			
			if(empty($count[0]['count'])){
				
				$this->modal_display('你还没有添加课程','/college/course_add/'."?id={$id}");
				header('Location:'.'/college/course_add/'."?id={$id}");
			}
			
			$info  = $this->paging($num,$sql1,$sql2);
			
			$this->view->assign('course',$info['page_data']);
			
			$this->view->assign('paging',$info['paging']);
			
			$this->view->assign('these',$this);
			
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->display('college1/course_info.html');
		
		}
			
	}
	


}
?>