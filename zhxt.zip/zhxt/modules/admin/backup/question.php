<?php
namespace modules\admin;

use src\response;
use src\logger;

class question extends admin 
{
	
	public function __construct($database,$smarty,$redis,$apierrorcode) {
		//header('Content-type: application/json');
		//header('Access-Control-Allow-Origin:*');
		parent::__construct($database,$smarty,$redis,$apierrorcode);
			
	}
	
	public function __destruct() {
		
	}
		
	//实际添加题库
	public function question_list_add(){
		
		if($this->check_login()){
				
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			
				$classname = bob_input($_POST['classname']);
				
				$type = bob_input($_POST['type']);
				
				switch($type)
				{
					case 1:
						$classname_add = '---单选题库';
					break;
					
					default:
						$classname_add = '---多选题库';					
				}
				
				$classname = $classname.$classname_add;
				
				$creater_id = $this->get_id();
				
				$info = $this->pdo->select("select school_id from yd_user where id = {$creater_id} limit 1 ");
				
				$school_id = $info[0]['school_id'];
				
				$class_id = bob_input($_GET['c_id']);
				
				$sql = "insert into yd_question_class (`classname`,`school_id`,`creater_id`,`class_id`,`type`) values ('{$classname}',{$school_id},{$creater_id},{$class_id},{$type})";
				
				$id = $this->pdo->insert($sql);
				
				if($id){					
					$this->modal_display('新增题库成功',$this->get_permission(__METHOD__).QUERY_STRING);	
				}else{
					$this->modal_display('新增题库失败',$this->get_permission(__METHOD__).QUERY_STRING);
				}
							
			}
			
			$this->view->assign('user_info',$this->user_info);
						
			$this->view->display('question/question_class_add.html');
		}
			
	}
	
	//添加题库类别
	public function question_list(){
		
		if($this->check_login()){
			
			$num = 4;//每页的数量
			
			$id = $this->get_id();
			
			$info1 = $this->pdo->select("select school_id from yd_user where id = {$id} limit 1 ");
			
			$sql1 = "select count(*) as count from yd_class where school_id = {$info1[0]['school_id']}";
		
			$sql2 = "select * from yd_class where school_id = {$info1[0]['school_id']}";
		
			$total = $this->pdo->select($sql1);
					
			$info  = $this->paging($num,$sql1,$sql2);
		
			$this->view->assign('class',$info['page_data']);
		
			$this->view->assign('paging',$info['paging']);
		
			$this->view->assign('these',$this);
			
			$this->view->assign('user_info',$this->user_info);
		
			$this->view->display('question/question_class_list.html');
					
		}
	}
	
	
	//实际添加题库
	public function question_add(){
		
		if($this->check_login()){
			
			$q_id = bob_input($_GET['q_id']);
			
			$info = $this->pdo->select("select * from yd_question_class where id = {$q_id} limit 1 ");
			
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {	
			
				$name = bob_input($_POST['name']);
				
				$answer_list = json_encode(bob_input($_POST['answer_list']),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
				
				$correct_answer = json_encode(bob_input($_POST['correct_answer']),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
				
				$sql = "insert into yd_question_list (`q_id`,`name`,`answer_list`,`correct_answer`,`school_id`,`creater_id`,`class_id`,`type`) values ({$q_id},'{$name}','{$answer_list}','{$correct_answer}',{$info[0]['school_id']},{$info[0]['creater_id']},{$info[0]['class_id']},{$info[0]['type']})";
				
				$id = $this->pdo->insert($sql);
				
				if($id){					
					$this->modal_display('新增题目成功',$this->get_permission(__METHOD__).QUERY_STRING);	
				}else{
					$this->modal_display('新增题目失败',$this->get_permission(__METHOD__).QUERY_STRING);
				}
							
			}
			
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->assign('type',$info[0]['type']);
				
			$this->view->display('question/question_add.html');
		}
			
	}
	
	//题库列表
	public function question(){
		
		if($this->check_login()){
			
			$num = 4;//每页的数量
			
			$id = $this->get_id();
			
			$info1 = $this->pdo->select("select school_id from yd_user where id = {$id} limit 1 ");
			
			$sql1 = "select count(*) as count from yd_question_class where school_id = {$info1[0]['school_id']}";
		
			$sql2 = "select * from yd_question_class where school_id = {$info1[0]['school_id']}";
		
			$total = $this->pdo->select($sql1);
			
			if(empty($total[0]['count'])){
				
				$this->modal_display('请先增加题库先','/question/question_list/'.QUERY_STRING);	
			
			}else{
								
				$info  = $this->paging($num,$sql1,$sql2);
			
				$this->view->assign('class',$info['page_data']);
			
				$this->view->assign('paging',$info['paging']);
			
				$this->view->assign('these',$this);
				
				$this->view->assign('user_info',$this->user_info);
			
				$this->view->display('question/question_list.html');
									
			}
			
		}
			
	}
	
	
	
	
}
?>