<?php
namespace modules\admin;

use src\response;
use src\logger;

class exam extends admin 
{
	
	public function __construct($database,$smarty,$redis,$apierrorcode) {
		//header('Content-type: application/json');
		//header('Access-Control-Allow-Origin:*');
		parent::__construct($database,$smarty,$redis,$apierrorcode);
			
	}
	
	public function __destruct() {
		
	}
	
	
	public function study(){
		
		$id = $this->get_id();
		
		$info = $this->pdo->select("select * from yd_user_class where u_id={$id}");	
		
		if(empty($info)){
			$this->modal_display('你没参加任何班级，快点叫老师添加你进班级学习吧','/user/index/'.QUERY_STRING);	
		}else{
			
			$idd = '';
		
			foreach($info as $infos){
				$idd .= $infos['c_id'].',';
			}
			
			$idd = rtrim($idd,',');
			
			$num = 3;//每页的数量
				
			$sql1 = "select count(id) as count from yd_class where id in ({$idd})";
		
			$sql2 = "select classname,id from yd_class where id in ({$idd})";
		
			$info  = $this->paging($num,$sql1,$sql2);
			
			$this->view->assign('class',$info['page_data']);
			
			$this->view->assign('paging',$info['paging']);
			
			$class = $this->pdo->select("select classname,id from yd_class where id in ({$idd})");
			
			//$course = $this->pdo->select("select * from yd_course where class_id in ({$idd})");
			
			//$this->view->assign('course',$course);
			
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->assign('these',$this->pdo);
			
			$this->view->display('exam/study.html');
			
		}
			
	}
	
	
	//添加试卷
	public function exam_list(){
		
		if($this->check_login()){
			
			$num = 4;//每页的数量
			
			$id = $this->get_id();
			
			$info1 = $this->pdo->select("select school_id from yd_user where id = {$id} limit 1 ");
			
			$sql1 = "select count(*) as count from yd_class where school_id = {$info1[0]['school_id']}";
		
			$sql2 = "select * from yd_class where school_id = {$info1[0]['school_id']}";
		
			$total = $this->pdo->select($sql1);
					
			$info  = $this->paging($num,$sql1,$sql2);
		
			$this->view->assign('class',$info['page_data']);
		
			$this->view->assign('paging',$info['paging']);
		
			$this->view->assign('these',$this);
			
			$this->view->assign('user_info',$this->user_info);
		
			$this->view->display('exam/exam_list.html');
					
		}
		
	}
	

	//实际添加考卷
	public function exam_add(){
		
		if($this->check_login()){
			
			$c_id = bob_input($_GET['c_id']);
				
			$create_id = $this->get_id();
				
			$info = $this->pdo->select("select * from yd_class where id ={$c_id} ");
			
			$school_id = $info[0]['school_id'];	
			//单选多选的题库
			$info2 = $this->pdo->select("select id,classname,type from yd_question_class where class_id ={$c_id} and school_id= {$info[0]['school_id']} ");
			
			//实际要装的题库
			$info4 = array();
			
			foreach($info2 as $value){
					
				switch($value['type']){
					case 1:
						//单选题,把数组的所有元素外加总数加进去						
						$info3 = $this->pdo->select("select count(*) as count from yd_question_list where q_id = {$value['id']}"); 
						$value['totalnum'] = $info3[0]['count'];
						$info4['radio'][] = $value;
					break;
					
					default:
						//2为多选题
						$info3 = $this->pdo->select("select count(*) as count from yd_question_list where q_id = {$value['id']}"); 
						$value['totalnum'] = $info3[0]['count'];
						$info4['checkbox'][] = $value;			
						
				}
			}		
			
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
				
				try{		
					$name = bob_input($_POST['name']);
				
					$dead_line = bob_input($_POST['dead_line']);
					
					$pass_line = bob_input($_POST['pass_line']);
					
					$e_data1 = bob_input($_POST['E_Date1']);
					
					$e_data2 = bob_input($_POST['E_Date2']);
					
					$radio_set = !empty($_POST['radio_set']) ? json_encode(bob_input($_POST['radio_set']),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : '';
					
					$radio_point = !empty($_POST['radio_point']) ? bob_input($_POST['radio_point']):0;
					
					$radio_num = !empty($_POST['radio_num']) ? bob_input($_POST['radio_num']):0;
					
					$checkbox_set = !empty($_POST['checkbox_set']) ? json_encode(bob_input($_POST['checkbox_set']),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : '';
					
					$checkbox_point = !empty($_POST['checkbox_point']) ? bob_input($_POST['checkbox_point']):0;
					
					$checkbox_num = !empty($_POST['checkbox_num']) ? bob_input($_POST['checkbox_num']):0;
							
					$sql = "insert into yd_exam (`c_id`,`school_id`,`creater_id`,`radio_set`,`radio_point`,`radio_num`,`checkbox_set`,`checkbox_point`,`checkbox_num`,`dead_line`,`pass_line`,`name`,`start_time`,`end_time`) values ({$c_id},{$school_id},{$create_id},'{$radio_set}',{$radio_point},{$radio_num},'{$checkbox_set}',{$checkbox_point},{$checkbox_num},{$dead_line},{$pass_line},'{$name}','{$e_data1}','{$e_data2}')";
					
					$id = $this->pdo->insert($sql);
					
					if($id){					
						$this->modal_display('新增试卷成功',$this->get_permission(__METHOD__).QUERY_STRING);	
					}else{
						$this->modal_display('新增试卷失败',$this->get_permission(__METHOD__).QUERY_STRING);
					}
					
				}catch (\Exception $e) {//就算是PDOException,也能接到
					
					//$this->modal_display('有错误发生，请仔细检查你的表单有没漏填项',$this->get_permission(__METHOD__).QUERY_STRING);
					
					exit("<b>" . '文件名：'.$e->getFile().'<br>   message：<br>   '.$e->getMessage()  .'<br>   行数：   '. $e->getLine().'</b>');
				}
							
			}
			
			$this->view->assign('radio_sets',$info4['radio']);
			
			$this->view->assign('checkbox_sets',$info4['checkbox']);
			
			$this->view->assign('user_info',$this->user_info);
						
			$this->view->display('exam/exam_add.html');
		}
			
	}
	
	
	public function do_practice(){
		
		$e_id = bob_input($_GET['e_id']);
		
		$info = $this->pdo->select("select * from yd_exam where id = {$e_id} limit 1");
		
		$array = [0=>"A",1=>'B',2=>"C",3=>"D",4=>"E",5=>"F",6=>"G"];
		
		//实际装填题目的数组，先装单选题,
		$question_actual = array();
		
		if(!empty($info[0]['radio_set'])){
			
			$radio_set = json_decode($info[0]['radio_set']);
			
			foreach($radio_set as $radio_sets){
				
				$infomation = $this->pdo->select("select * from yd_question_list where q_id = {$radio_sets}");
			
				foreach($infomation as $infomations){
					
					$infomations['pts'] = $info[0]['radio_point']/$info[0]['radio_num'];
					
					$i=0;//定义初始值
					$infomations['answer_list'] = json_decode($infomations['answer_list']);
					$answer_list_count = count($infomations['answer_list']);
					for($i=0;$i<$answer_list_count;$i++){
						if(empty($infomations['answer_list'][$i])){
							unset($infomations['answer_list'][$i]);
						}
					}				
					
					//$infomations['correct_answer'] = json_decode($infomations['correct_answer']);
					
					$question_actual[] = $infomations;
					
				}
				 
			}
			
		}
		
		if(!empty($info[0]['checkbox_set'])){
			
			$checkbox_set = json_decode($info[0]['checkbox_set']);
			
			foreach($checkbox_set as $checkbox_sets){
				
				$infomation = $this->pdo->select("select * from yd_question_list where q_id = {$checkbox_sets}");
			
				foreach($infomation as $infomations){
					$infomations['pts'] = $info[0]['checkbox_point']/$info[0]['checkbox_num'];
					
					$i=0;//定义初始值
					$infomations['answer_list'] = json_decode($infomations['answer_list']);
					$answer_list_count = count($infomations['answer_list']);
					for($i=0;$i<$answer_list_count;$i++){
						if(empty($infomations['answer_list'][$i])){
							unset($infomations['answer_list'][$i]);
						}
					}
					
					//$infomations['correct_answer'] = json_decode($infomations['correct_answer']);
					$question_actual[] =$infomations;
				}
				 
			}
			
		}
		
		$question_page = $this->exam_page($question_actual);
		
		$this->view->assign('head_link',$question_page['url_head_link']);
		
		$this->view->assign('footer_link',$question_page['url_footer_link']);
		
		$this->view->assign('question_actual',$question_actual);
		
		$this->view->assign('array',$array);
		
		$this->view->assign('user_info',$this->user_info);
		
		$this->view->display('exam/practice.html');
		
	}
	
	public function do_exam(){
		
		$e_id = bob_input($_GET['e_id']);
		
		$info = $this->pdo->select("select * from yd_exam where id = {$e_id} limit 1");
		//p($info[0]['checkbox_set']);
		
		//实际装填单选题的数组
		$radio_actual = array();
		
		if(!empty($info[0]['radio_set'])){
			
			$radio_set = json_decode($info[0]['radio_set']);
			
			foreach($radio_set as $radio_sets){
				
				$infomation = $this->pdo->select("select id from yd_question_list where q_id = {$radio_sets}");
			
				foreach($infomation as $infomations){
					$radio_actual[] =$infomations['id'];
				}
				 
			}
			
			$radio_actual = array_flip($radio_actual);//键，值互换
			
			//实际抽取的题目
			$radio_actual = array_rand($radio_actual,$info[0]['radio_num']);//抽取指定数量的键名
			
		}
		
		
		//实际装填多选题的数组
		$checkbox_actual = array();
		
		if(!empty($info[0]['checkbox_set'])){
			
			$checkbox_set = json_decode($info[0]['checkbox_set']);
			
			foreach($checkbox_set as $checkbox_sets){
				
				$infomation = $this->pdo->select("select id from yd_question_list where q_id = {$checkbox_sets}");
			
				foreach($infomation as $infomations){
					$checkbox_actual[] =$infomations['id'];
				}
				 
			}
			
			$checkbox_actual = array_flip($checkbox_actual);//键，值互换
			
			//实际抽取的题目
			$checkbox_actual = array_rand($checkbox_actual,$info[0]['checkbox_num']);//抽取指定数量的键名
			
		}
		
		p($radio_actual);
		
		$this->view->display('exam/practice.html');
		
	}
	
	public function practice_list(){
		
		$id = $this->get_id();
		
		$info1 = $this->pdo->select("select c_id from yd_user_class where u_id = {$id}");
		
		if(empty($info1)){
			
			$this->modal_display('快叫你的老师加你进班级吧!','/user/index/'.QUERY_STRING);
				
		}else{
			
			$c_id = '';
			
			foreach($info1 as $info_1){
				
				$c_id .= $info_1['c_id'].',';
				
			}
			
			$c_id = rtrim($c_id,',');
			
			$sql1 = "select count(*) as count from yd_exam where c_id in ({$c_id}) ";
		
			$sql2 = "select id,name,dead_line,pass_line,start_time,end_time from yd_exam where c_id in ({$c_id}) ";
		
			$total = $this->pdo->select($sql1);
			
			if(empty($total)){
				$this->modal_display('快叫你的老师创建试卷吧!','/user/index/'.QUERY_STRING);	
			}
			
			$num = 5 ;
					
			$info2  = $this->paging($num,$sql1,$sql2);
		
			$this->view->assign('infos',$info2['page_data']);
		
			$this->view->assign('paging',$info2['paging']);
			
			$this->view->assign('these',$this);
			
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->display('exam/practice_list.html');
		}	
		
	}
		

}
?>