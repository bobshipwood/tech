<?php
namespace modules\admin;

use src\response;
use src\logger;

class procedure extends admin 
{
	
	public function __construct($database,$smarty,$redis,$apierrorcode) {
		//header('Content-type: application/json');
		//header('Access-Control-Allow-Origin:*');
		parent::__construct($database,$smarty,$redis,$apierrorcode);
			
	}
	
	public function __destruct() {
		
	}
	
	public function review(){
		
		if($this->check_login()){
			
			$id = $this->get_id();
			
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
				
				$class_id = bob_input($_POST['id']);
				
				$sql = "update yd_class set review_id = {$id},review = 1 where id = {$class_id} ";
			
				try{
				
					$this->pdo->update($sql);
				
					$this->modal_display('成功审批',$this->get_permission(__METHOD__).QUERY_STRING);
								
				}catch (\PDOException $e) {
					$this->modal_display('审批失败',$this->get_permission(__METHOD__).QUERY_STRING);
				}
				
			}

			$num = 5;//每页的数量
				
			$info1 = $this->pdo->select("select school_id from yd_user where id = {$id} limit 1 ");
			
			$sql1 = "select count(*) as count from yd_class where school_id = {$info1[0]['school_id']}";
		
			$sql2 = "select * from yd_class where school_id = {$info1[0]['school_id']}";
		
			$info  = $this->paging($num,$sql1,$sql2);
			
			$this->view->assign('class',$info['page_data']);
			
			$this->view->assign('paging',$info['paging']);
			
			$this->view->assign('these',$this);
			
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->display('procedure/review.html');
	
		}
		
	}
	
	public function approve(){
		
		
		if($this->check_login()){
			
			$id = $this->get_id();
			
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
				
				$class_id = bob_input($_POST['id']);
				
				$sql = "update yd_class set approve_id = {$id},approve = 1 where id = {$class_id} ";
			
				try{
				
					$this->pdo->update($sql);
				
					$this->modal_display('成功批准',$this->get_permission(__METHOD__).QUERY_STRING);
								
				}catch (\PDOException $e) {
					$this->modal_display('批准失败',$this->get_permission(__METHOD__).QUERY_STRING);
				}
				
			}

			$num = 5;//每页的数量
				
			$info1 = $this->pdo->select("select school_id from yd_user where id = {$id} limit 1 ");
			
			$sql1 = "select count(*) as count from yd_class where school_id = {$info1[0]['school_id']} and review = 1";
		
			$sql2 = "select * from yd_class where school_id = {$info1[0]['school_id']} and review = 1";
		
			$info  = $this->paging($num,$sql1,$sql2);
			
			$this->view->assign('class',$info['page_data']);
			
			$this->view->assign('paging',$info['paging']);
			
			$this->view->assign('these',$this);
			
			$this->view->assign('user_info',$this->user_info);
			
			$this->view->display('procedure/approve.html');
	
		}
		
	}

}
?>