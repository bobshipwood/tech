<?php
namespace modules\admin;

use src\response;
use src\logger;
use src\register;

class admin {
	
	
	protected $pdo,$apierrorcode,$view,$redis;
	
	protected $user_info;
	
	public function __construct($database,$smarty,$redis,$apierrorcode) {
		
		$this->pdo = $database;
		
		$this->view = $smarty;
		
		$this->redis = $redis;
		
		$this->apierrorcode = $apierrorcode;
		
		//初始化模态框
		$this->view->assign('modal_display','hide');
		$this->view->assign('modal_message','');
		$this->view->assign('modal_url','/user/login/');
			
	}
	
	//检测是否登陆
	public function check_login(){
		
		if(empty($_GET['id'])){
				$this->modal_display('未登陆');
				return false;
		}else{
			
			$id = intval(bob_input($_GET['id']));
			
			$result = $this->redis->get($id);
			
			if($result==false){
				$this->modal_display('登陆异常');
				return false;
			}else{
				//拿用户的信息
				$this->user_info = $this->pdo->select("select * from yd_user where id = {$id}");
				//$this->modal_display('登陆成功');
				return true;
			}
			
		}
	}
	
	//返回当前操作的类和方法，如/user/index/,其中参数是__METHOD__
	public function get_permission($method){
		
		$method = explode('\\',$method);
		$method = explode('::',$method[2]);
		$permission ='/'.$method[0].'/'.$method[1].'/';//   /user/user_add/ 
		return $permission;
	}
	
	
	
	public function check_permission($method){
		
		$permission =$this->get_permission($method);//传递进来的方法，用来提取权限
		
		$id = $this->get_id();
		
		$permissions = $this->get_role($id);
		
		if(in_array($permission, $permissions)){
			return true;
		}else{
			return false;
		}
		
		
	}
	
	//根据用户id查找权限,返回array.后期可能改为根据加密字符串
	public function get_role($id){
		
		$info1 = $this->pdo->select("select role from yd_user where id = {$id} limit 1 ");
		
		$info = $this->pdo->select("select p_id from yd_role_permission where r_id = {$info1[0]['role']} ");
		
		$sql_in = '';
		
		foreach ($info as $infos){
			$sql_in .= $infos['p_id'].',';
		}
		
		$sql_in = rtrim($sql_in,',');
		
		$role = $this->pdo->select("select * from yd_permission where id in ({$sql_in})");
		
		$array = [];
		
		foreach($role as $roles){
			$array[] = $roles['permission'];
		}
		
		return $array;
		
	}
	
	public function get_id(){
		
		$id = intval(bob_input($_GET['id']));
		
		return $id;
	}
	
	
	
	//用户加密规则
	public function descrypt($password,$salt){
		
		$descrypt_text = md5($password.$salt);
		return $descrypt_text;
		
	}
	
	//根据用户id查找用户名字
	public function get_name($id){
		
		$info = $this->pdo->select("select username from yd_user where id = {$id} limit 1 ");
		if(empty($info)){
			return '';
		}else{
			return $info[0]['username'];
		}
		
	}
	
	//根据登陆id查找同校学生,带分页
	public function get_schoolmates(){
		
		$id = $this->get_id();
		
		$info = $this->pdo->select("select school_id from yd_user where id = {$id} limit 1 ");
		//分页开始		
		$item = 5;//每页多少条
		
		$sql1 = "select count(*) as count from yd_user where school_id = {$info[0]['school_id']}";
		
		$sql2 = "select * from yd_user where school_id = {$info[0]['school_id']}";
		//准备返回的数组
		$array = [];
		
		$array2 = $this->paging($item,$sql1,$sql2);
		
		$array['paging'] = $array2['paging'];
			
		$array['schoolmates'] = $array2['page_data'];
	
		return $array;
		
	}
	
	//根据用户表的学校id查找学校名字
	public function get_school($id){
		
		$info = $this->pdo->select("select name from yd_school where id = {$id} limit 1 ");
		
		return $info[0]['name'];
		
	}
	
	//根据班级表的id查找班级名字
	public function get_class($id){
		
		$info = $this->pdo->select("select classname from yd_class where id = {$id} limit 1 ");
		
		return $info[0]['classname'];
		
	}
	
	
	
	//模态框弹出
	public function modal_display($modal_message='',$modal_url='/user/login/'){
		
		//初始化模态框
		$this->view->assign('modal_display','show');
		$this->view->assign('modal_message',$modal_message);
		$this->view->assign('modal_url',$modal_url);
		//$this->view->display('modal.html');
		//exit;
		
	}
	
	
	
	public function paging($item,$sql1,$sql2)
	{
		$item = $item;//每页多少条
		
		$array = [];
		
		$array['paging'] = $this->paging_info($sql1,$item);
			
		$array['page_data'] = $this->page_data($sql1,$sql2,$item);
	
		return $array;
			
	}
	
	/**
     *
     * 分页
	 * $items 每页条数
	 * $sql1 求总数的sql语句
     * @return 整个分页
     */
	public function paging_info($sql1,$item){
		
		$total = $this->pdo->select($sql1);
		
		if($total[0]['count']<=0){
			
			exit('没有总数');
		
		}
		
		$total = $total[0]['count'];
		
		$total_page = $total/$item;//求出总页数
		
		if(!is_int($total_page)){
		
			$total_page = intval($total_page)+1;

		}
		
		//获取当前url
		$url = $_SERVER["REQUEST_SCHEME"].'://'.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];  
		
		//判断要在url后面加的？还是&
		if(strpos($url, '?')){
			
			$connector = '&page=';
		
		}else{
		
			$connector = '?page=';

		}
					
		//首页
		
		$url_head_link = isset($_GET['page']) && intval($_GET['page']) ? preg_replace("/page=\d*/",'page=1',$url)  : $url.$connector.'1';
		
		$url_head = "<nav aria-label='Page navigation' style='text-align: center;'>
		  <ul class='pagination'>
			<li>
			  <a href='{$url_head_link}' aria-label='Previous'>
				<span aria-hidden='true'>&laquo;</span>
			  </a>
			</li>";
					
		//中间所有页	
		$url_mid = '';
		
		for($i=1;$i<=$total_page;$i++){
			$url_mid_link = isset($_GET['page']) && intval($_GET['page']) ? preg_replace("/page=\d*/",'page='.$i,$url)  : $url.$connector.$i;
			$url_mid .= "<li><a href='{$url_mid_link}'>{$i}</a></li>";
		}
		
		//尾页
		$url_footer_link = isset($_GET['page']) && intval($_GET['page']) ? preg_replace("/page=\d*/",'page='.$total_page,$url)  : $url.$connector.$total_page;
		
		$url_footer = "<li>
			  <a href='{$url_footer_link}' aria-label='Next'>
				<span aria-hidden='true'>&raquo;</span>
			  </a>
			</li>
		  </ul>
		</nav>";

		$url_foo = 	$url_head.$url_mid.$url_footer;
		
		return $url_foo;
					
	}


	/**
     *
     * 分页数据
	 * $items 每页条数
	 * SQL2 实际数据语句
     * @return 实际数据
     */
	public function page_data($sql1,$sql2,$item)
    {
		$total = $this->pdo->select($sql1);
		
		if($total[0]['count'] <= $item){
			
			$data = $this->pdo->select($sql2);
			
			return $data;
		
		}else{
			
			$page = isset($_GET['page']) && intval($_GET['page']) ? intval($_GET['page']) : 1;
		
			$page = $page - 1;//第几页
			
			if($page<0){
				exit('page不能小于0');
			}
			
			$page_start = $page*$item;
				
			$sql2_full = $sql2." limit {$page_start},{$item}";
			
			$data = $this->pdo->select($sql2_full);
			
			return $data;
			
		}
		
        
    }
	
	public function replace_query($key,$value)
	{
		
		$query = explode('&',$_SERVER['QUERY_STRING']);
	
		$str = '';//匹配后的字符串,如c_id=2&id=2
		
		$query_count = count($query);
		
		for($i=0;$i<$query_count;$i++){
		
			$result = explode('=',$query[$i]);
			
				if($result[0]==$key){
					
					$result[1] = $value;
				
				}
			
			$str .= $result[0].'='.$result[1].'&';
		}
		
		$str = rtrim($str,'&');
		
		$str = '?'.$str;
	
		return $str;
	}
	
	
	/**
     *
     * 分题
     * @return 整个分页
     */
	public function exam_page($item){
		
		$total_page = count($item);//求出总页数
		
		//获取当前url
		$url = $_SERVER["REQUEST_SCHEME"].'://'.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];  
		
		
		//判断要在url后面加的？还是&
		if(strpos($url, '?')){
			
			$connector = '&q_page=';
		
		}else{
		
			$connector = '?q_page=';

		}
		
		if(isset($_GET['q_page'])){
			//如果当前get的page大于总数，则跳回第一页
			if($_GET['q_page']>$total_page){
				$url = preg_replace("/q_page=\d*/",'q_page=1',$url);
				header('Location:'.$url); 
				exit;
			}
			
		}else{
			//如果没有当前get，则跳回第一页
			$url=  $url.$connector.'1';
			header('Location:'.$url); 
			exit;
		
		}	
		
		//上一页	
		if(isset($_GET['q_page']) && $_GET['q_page']!=1){	
			$url_head_link = preg_replace("/q_page=\d*/",'q_page='.($_GET['q_page']-1),$url);
		}else{				
			$url_head_link = isset($_GET['q_page']) && intval($_GET['q_page']) ? preg_replace("/q_page=\d*/",'q_page=1',$url)  : $url.$connector.'1';
		}
	
		//下一页
		if(isset($_GET['q_page']) && $_GET['q_page']==$total_page){	
			$url_footer_link = preg_replace("/q_page=\d*/",'q_page='.$total_page,$url);
		}else{
			$url_footer_link = isset($_GET['q_page']) && intval($_GET['q_page']) ? preg_replace("/q_page=\d*/",'q_page='.($_GET['q_page']+1),$url)  : $url.$connector.'2';
		}
		
		$array = array();
		
		$array['url_head_link'] = $url_head_link;
		
		$array['url_footer_link'] = $url_footer_link;
		
		return $array;
					
	}

	
	public function __destruct() {
		
	}
	
	
	//http请求
	public function http_request($url, $data = null)
	{
		//$headers = array('Content-Type: application/json');
		
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		if (!empty($data)){
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		
		//curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
		
		//curl_setopt($curl, CURLOPT_HEADER, TRUE);    //表示需要response header
		
		//curl_setopt($curl, CURLOPT_NOBODY, FALSE); //表示需要response body
		
		$output = curl_exec($curl);
		
		curl_close($curl);
		
		return $output;
	}
	


}
?>