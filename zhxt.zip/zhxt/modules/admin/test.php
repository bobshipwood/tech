<?php
namespace modules\admin;

use src\response;
use src\logger;

class test extends admin
{
	
	
	
	public function __construct($database,$smarty,$redis,$apierrorcode) {
		//header('Content-type: application/json');
		//header('Access-Control-Allow-Origin:*');
		parent::__construct($database,$smarty,$redis,$apierrorcode);
			
	}
	
	public function __destruct() {
		
	}
	
	//http请求
	public function http_request($url, $data = null)
	{
		//$headers = array('Content-Type: application/json');
		
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		if (!empty($data)){
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		
		//curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
		
		//curl_setopt($curl, CURLOPT_HEADER, TRUE);    //表示需要response header
		
		//curl_setopt($curl, CURLOPT_NOBODY, FALSE); //表示需要response body
		
		$output = curl_exec($curl);
		
		curl_close($curl);
		
		return $output;
	}
	
	public function redis()
	{
		$this->redis->set("tutorial-key", "Redis test");
		 
		echo "Stored string in redis:: " . $this->redis->get("tutorial-key");
	
	}
	
	
	
	public function test()
	{
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
				
			try{		
			
				$dead_line = bob_input($_POST['dead_line']);
				
				$pass_line = bob_input($_POST['pass_line']);
				
				$radio_set = bob_input($_POST['radio_set']);
				
				$radio_point = bob_input($_POST['radio_point']);
				
				$radio_num = bob_input($_POST['radio_num']);
				
				$checkbox_set = bob_input($_POST['checkbox_set']);
				
				$checkbox_point = bob_input($_POST['checkbox_point']);
				
				$checkbox_num = bob_input($_POST['checkbox_num']);
					
				$sql = "insert into yd_exam (`c_id`,`school_id`,`creater_id`,`radio_set`,`radio_point`,`radio_num`,`checkbox_set`,`checkbox_point`,`checkbox_num`) values ({$c_id},{$school_id},{$creater_id},'{$radio_set}','{$radio_point}','{$radio_num}','{$checkbox_set}','{$checkbox_point}','{$checkbox_num}')";
			
				$id = $this->pdo->insert($sql);
				
				if($id){					
					$this->modal_display('新增试卷成功',$this->get_permission(__METHOD__).QUERY_STRING);	
				}else{
					$this->modal_display('新增试卷失败',$this->get_permission(__METHOD__).QUERY_STRING);
				}
				
			}catch (\Exception $e) {
	   
				exit("<b>" . '文件名：'.$e->getFile().'<br>   message：<br>   '.$e->getMessage()  .'<br>   行数：   '. $e->getLine().'</b>');
			}
							
		}
			
		$this->view->assign('info',$info);
						
		$this->view->display('exam/exam_add.html');
			
	}
	
	
	
	public function ob_start(){
		
		ob_start();
		
		var_dump(111);
		
		$info = ob_get_contents();
		
		//ob_end_clean();//clean ob, end ob
		ob_end_flush();//flush ob to browser, end ob 
		
	}
	
	
	
	public function ossupload($object,$filePath){

		// 阿里云主账号AccessKey拥有所有API的访问权限，风险很高。强烈建议您创建并使用RAM账号进行API访问或日常运维，请登录 https://ram.console.aliyun.com 创建RAM账号。
		$accessKeyId = "LTAIoxD5aoJcQZhX";
		$accessKeySecret = "PoRLfPTiMkpNmMnoA1xWsxfbDWkXqJ";
		// Endpoint以杭州为例，其它Region请按实际情况填写。
		$endpoint = "http://oss-cn-shanghai.aliyuncs.com";
		// 存储空间名称
		$bucket= "venucia2019";
		// 上传到oss的文件名称http://venucia2019.oss-cn-shanghai.aliyuncs.com/｛object｝
		//$object = '';
		// 文件内容
		//$content = "Hello OSS";
		// <yourLocalFile>由本地文件路径加文件名包括后缀组成，例如/users/local/myfile.txt
		//$filePath = '';
		
		try{
		
			$ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint);

			//$ossClient->putObject($bucket, $object, $content);
			
			$ossClient->uploadFile($bucket, $object, $filePath);			
		
		} catch(OssException $e) {
			
			printf(__FUNCTION__ . ": FAILED\n");
			
			printf($e->getMessage() . "\n");
			
			exit;
		}
		
		
	}
	
	
	public function upload_base64(){	
	
		header('Access-Control-Allow-Origin:*');
		
		$yinyong = __DIR__;
		$yinyong = $yinyong.'..'.DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'..';
		$yinyong = realpath($yinyong);
		
		// 指定允许其他域名访问	
		//header('Access-Control-Allow-Origin:*');
		// 响应类型
		//header('Access-Control-Allow-Methods:POST');
		// 响应头设置
		//header('Access-Control-Allow-Headers:x-requested-with,content-type');
		
		try{

			$microtime = microtime(true);
					
			$mtime = explode('.',$microtime);
			
			$object = $mtime[0].$mtime[1].'h6';				
							
			//if (preg_match('/^(data:\s*image\/(\w+);base64,)/', $_POST['file_base64'], $result)){
				
			//$ext =  $result[2];
			
			// if($ext=='jpeg'){
				// $ext = '.jpg';
			// }
			
			$ext = '.png';
			
			$filename = $object.$ext;
			
			$file_base64 = $_POST['file_base64'];
			
			//$file_base64 = str_replace("_","+",$_POST['file_base64']);
			
			$file_base64 = str_replace(" ","+",$_POST['file_base64']);
			
			logger::loging('shangchuan3.log',$file_base64.PHP_EOL);
			
			//p(strlen($file_base64));
			
			//p($file_base64);
			//$file_base64 = preg_replace('/data:image\/png;base64,/i', '', $file_base64);
		//p($file_base64);	
			$file_base64 = explode(',',$file_base64);
			
			$file_base64 = $file_base64[1];
			
			//p(strlen($file_base64));
			
			$file_base64 = base64_decode($file_base64);
			
			$url = $yinyong.DIRECTORY_SEPARATOR.'public'.DIRECTORY_SEPARATOR.'static'.DIRECTORY_SEPARATOR.$filename;
		
			file_put_contents($url, $file_base64);
			
			$this->ossupload($filename,$url);
			
			$date = date("Y-m-d H:i:s");
			
			$database = array (
				'default' => array (
					'hostname' => 'localhost',
					'port' => 3306,
					'database' => 'usefultest',
					'username' => 'root',
					'password' => 'root',
				),
				'yishizhengshi' => array (
					'hostname' => '114.215.206.212',
					'port' => 3306,
					'database' => 'vber',
					'username' => 'bobshipwood',
					'password' => 'bobshipwood',
				)
				
			);
			
			$this->pdo2 = $this->pdo->changeInstance($database['default']);
			
			$datatime = date('Y').date('m').date('d').date('H').date('i').date('s').'000';
			
			$id = $this->pdo2->insert("insert into long_test(imgurl,datetime) values ('{$filename}','{$datatime}')");
				
			unlink($url);
			
			// //echo response::json(200,$this->apierrorcode['20000'],[['url'=>'http://venucia2019.oss-cn-shanghai.aliyuncs.com/'.$filename]]);
				
			echo '{"code":200,"message":"\u67e5\u8be2\u6210\u529f","data":[{"id":"'.$id.'","crtime":"2018-11-25 14:50:18","uptime":"2018-11-25 14:50:18","url":"'.'http://venucia2019.oss-cn-shanghai.aliyuncs.com/'.$filename.'","status":"1","downtime":"20181125145018000","choicetime":"'.$datatime.'","pickey":"1","machinetype":"iphone7","source":"4"}]}';
		
			exit;

		}catch(PDOException $e){
			
			echo response::json(40000,$this->apierrorcode['40000']);
			
			//$this->pdo->rollback();
			
			exit;
			
		}
		
		
	}
	
	public function download(){
		
		$database = array (
			'default' => array (
				'hostname' => 'localhost',
				'port' => 3306,
				'database' => 'usefultest',
				'username' => 'root',
				'password' => 'root',
			),
			'yishizhengshi' => array (
				'hostname' => '114.215.206.212',
				'port' => 3306,
				'database' => 'vber',
				'username' => 'bobshipwood',
				'password' => 'bobshipwood',
			)
			
		);
		
		$this->pdo2 = $this->pdo->changeInstance($database['default']);
		
		$res = $this->pdo2->execall("select * from long_test where datetime-'{$_GET['time']}'>0 order by datetime desc ");
				
		$shuju = array();		
				
		foreach($res as $k=>$v){
			
			$shuju[$k]['url'] = 'http://venucia2019.oss-cn-shanghai.aliyuncs.com/'.$v['imgurl'];
			
			$shuju[$k]['datetime'] = $v['datetime'];
			
		}		
				
		echo response::json(20000,$this->apierrorcode['20000'],$shuju);
			
		exit;
		
	}
	

}
?>